<?php
/*
    GET_data_info.php

    This file handles AJAX requests for retrieving specific records from the database tables based on their IDs.

    Features:
    - Retrieves a specific record from the database based on the provided table name and ID stored in the URL parameter.
    - Supports various tables including suppliers, categories, products, and users.
    - Utilizes SQL queries to fetch the requested record from the database.
    - Handles missing or invalid parameters to prevent SQL injection and ensure data integrity.
    - Outputs the retrieved record in JSON format for consumption by frontend components.

*/

require_once ('../../required/db_conn.php');

// Check if both tbl and data parameters are present
if (isset($_GET['tbl']) && isset($_GET['data'])) {
    // Retrieve tbl and data parameters
    $tbl = $_GET['tbl'];
    $data = $_GET['data'];

    $sql = "SELECT * FROM ";

    if (empty($data)) {
        echo <<<HTML
            <div style="text-align: center;">
                <h1 style="font-weight: bold;">OH NO!</h1>
                <h5>The page you're looking for does not exist, or has been moved</h5>
                <h6>Please return to <a href="/Inventory/?p=dashboard">Dashboard</a></h6>
            </div>
        HTML;
        exit();
    }

    // Determine which table to query based on the tbl parameter
    switch ($tbl) {
        case 'supplier':
            $sql .= 'supplier_tbl WHERE supplier_id = ' . $data;
            break;
        case 'categories':
            $sql .= 'categories_tbl WHERE category_id = ' . $data;
            break;
        case 'products':
            $sql .= 'products_tbl WHERE product_id = ' . $data;
            break;
        case 'users':
            $sql .= 'users_tbl WHERE user_id = ' . $data;
            break;
        case 'products_user':
            $sql = "SELECT 
                        p.product_id,
                        p.product_name,
                        p.image,
                        c.category_name AS category,
                        s.supplier_name AS supplier,
                        p.selling_price as selling_price_int,
                        CONCAT('₱ ', FORMAT(p.selling_price, 2)) AS selling_price,
                        DATE_FORMAT(p.created_at, '%M %d, %Y ') AS created_at,
                        p.stock_value AS total_stock,
                        (SELECT unit
                        FROM (
                        SELECT unit, COUNT(*) AS unit_count
                    FROM restock_tbl
                    JOIN products_tbl p ON restock_tbl.product_id = p.product_id
                    WHERE p.product_id = " . $data .
                " GROUP BY unit
                    ORDER BY unit_count DESC
                    LIMIT 1
                        ) AS t) AS unit
                    FROM 
                        products_tbl p
                    JOIN 
                        categories_tbl c ON p.category_id = c.category_id
                    JOIN 
                        supplier_tbl s ON p.supplier_id = s.supplier_id
                    WHERE 
                        p.product_id = " . $data;
            break;
        default:
            // If tbl is not recognized, output an error
            echo <<<HTML
                <div style="text-align: center;">
                    <h1 style="font-weight: bold;">OH NO!</h1>
                    <h5>The page you're looking for does not exist, or has been moved</h5>
                    <h6>Please return to <a href="/Inventory/?p=dashboard">Dashboard</a></h6>
                </div>
            HTML;
            exit();
    }

    $result = $conn->query($sql);

    // Check if any rows are returned
    if ($result->num_rows > 0) {
        // Fetch the row as an associative array
        $row = $result->fetch_assoc();

        // Output the record
        echo json_encode(array("data" => $row));
    } else {
        // Output error if no record is found
        echo json_encode(array("data" => array()));
    }

} else {
    // If tbl or data parameter is missing, display an error
    echo <<<HTML
        <div style="text-align: center;">
            <h1 style="font-weight: bold;">OH NO!</h1>
            <h5>The page you're looking for does not exist, or has been moved</h5>
            <h6>Please return to <a href="/Inventory/?p=dashboard">Dashboard</a></h6>
        </div>
    HTML;
    exit(); // Stop further execution
}

?>