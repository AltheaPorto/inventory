<?php
/*
    GET_dashboard.php

    This file handles AJAX requests for retrieving dashboard data used in the StockSense Inventory Management System.

    Features:
    - Retrieves various data for the dashboard, including user counts, product information, user details, and recent orders.
    - Supports different data types based on the 'data' parameter passed in the GET request.
    - Utilizes SQL queries to fetch relevant data from the database.
    - Implements error handling mechanisms to handle missing or invalid parameters and database query errors.
    - Outputs JSON-formatted data for consumption by the dashboard frontend.

*/

require_once ('../../required/db_conn.php');

if (isset($_GET['data'])) {
    $dataParam = $_GET['data'];

    switch ($dataParam) {
        case 'counter':
            // Get total number of users
            $userCountQuery = "SELECT COUNT(*) AS user_count FROM users_tbl";
            $userResult = $conn->query($userCountQuery);
            $userCount = $userResult->fetch_assoc()['user_count'];

            // Get total number of active categories
            $categoryCountQuery = "SELECT COUNT(*) AS category_count FROM categories_tbl WHERE status = 'Active'";
            $categoryResult = $conn->query($categoryCountQuery);
            $categoryCount = $categoryResult->fetch_assoc()['category_count'];

            // Get total number of products
            $productCountQuery = "SELECT COUNT(*) AS product_count FROM products_tbl";
            $productResult = $conn->query($productCountQuery);
            $productCount = $productResult->fetch_assoc()['product_count'];

            $orderCountQuery = "SELECT COUNT(*) AS order_count FROM orders_tbl";
            $orderResult = $conn->query($orderCountQuery);
            $orderCount = $orderResult->fetch_assoc()['order_count'];

            // Create an associative array to hold the counts
            $data = array(
                'user_count' => $userCount,
                'category_count' => $categoryCount,
                'product_count' => $productCount,
                'order_count' => $orderCount,
            );

            break;

        case 'products':
            // SQL query to select the last 10 added products
            $query = "SELECT 
                        products_tbl.product_name,
                        CONCAT('₱', FORMAT(products_tbl.selling_price, 2)) AS selling_price,
                        products_tbl.stock_value
                    FROM 
                        products_tbl
                    ORDER BY
                        products_tbl.created_at DESC
                    LIMIT
                        6";

            // Execute the query
            $result = $conn->query($query);

            // Check if there are any results
            if ($result && $result->num_rows > 0) {
                // Fetch the results into an array
                $data = $result->fetch_all(MYSQLI_ASSOC);
            } else {
                // Handle no results found
                $data = array();
            }
            break;

        case 'user':
            $query = "SELECT 
                        users_tbl.username,
                        CONCAT(users_tbl.first_name, ' ', users_tbl.last_name) AS name,
                        CASE users_tbl.role
                            WHEN 0 THEN 'Admin'
                            WHEN 1 THEN 'User'
                            WHEN 2 THEN 'Employee'
                            ELSE 'Unknown'
                        END AS role
                    FROM 
                        users_tbl
                    ORDER BY
                        users_tbl.created_at DESC
                    LIMIT
                        6";

            $result = $conn->query($query);

            // Check if there are any results
            if ($result && $result->num_rows > 0) {
                // Fetch the results into an array
                $data = $result->fetch_all(MYSQLI_ASSOC);
            } else {
                // Handle no results found
                $data = array();
            }
            break;

        case 'orders':
            $query = "SELECT 
                        CONCAT(u.first_name, ' ', u.last_name) AS name,
                        p.image,
                        p.product_name AS product_name,
                        o.quantity AS quantity,
                        DATE_FORMAT(o.created_at, '%M %d, %Y - %h:%i %p') AS order_date
                    FROM 
                        orders_tbl AS o
                    JOIN 
                        users_tbl AS u ON o.user_id = u.user_id
                    JOIN 
                        products_tbl AS p ON o.product_id = p.product_id
                    ORDER BY 
                        o.created_at DESC
                    LIMIT
                        6;
                    ";

            $result = $conn->query($query);

            // Check if there are any results
            if ($result && $result->num_rows > 0) {
                // Fetch the results into an array
                $data = $result->fetch_all(MYSQLI_ASSOC);
            } else {
                // Handle no results found
                $data = array();
            }
            break;

        default:
            // Handle invalid data parameter
            echo "Invalid data parameter.";
            exit;
    }

    // Encode the array as JSON
    $jsonData = json_encode($data);

    // Output the JSON data
    header('Content-Type: application/json');
    echo $jsonData;
} else {
    // Handle missing data parameter
    echo "Missing data parameter.";
}
