<?php
/*
    post_users.php

    This file handles the creation, updating, and deletion of user accounts for buyers.

    Features:
    - Insert new user accounts into the users_tbl table.
    - Update existing user accounts in the users_tbl table.
    - Delete user accounts from the users_tbl table.

*/
require_once ('../../required/db_conn.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['delete_id'])) {
        // Handle deletion logic
        $delete_id = $_POST['delete_id'];

        // SQL query to delete a record from the supplier_tbl table
        $delete_query = "DELETE FROM `users_tbl` WHERE `user_id` = ?";

        // Prepare the statement
        $delete_stmt = $conn->prepare($delete_query);

        // Bind parameters
        $delete_stmt->bind_param("i", $delete_id);

        // Execute the statement
        if ($delete_stmt->execute()) {
            // Handle successful deletion
            echo "Record deleted successfully";
        } else {
            // Handle deletion failure
            echo "Error: " . $conn->error;
        }

        // Close statement
        $delete_stmt->close();
    } else {
        if ($_GET['action'] === 'update') {
            $recordID = $_POST['form_data_id'];
            $username = $conn->real_escape_string($_POST['form_username']);
            $firstName = $conn->real_escape_string($_POST['form_fName']);
            $lastName = $conn->real_escape_string($_POST['form_lName']);
            $password = $conn->real_escape_string($_POST['form_password']);
            $role = $_POST['form_role'];

            // Check if the username already exists excluding the current record
            $checkQuery = "SELECT COUNT(*) AS user FROM users_tbl WHERE username = ? AND user_id != ?";
            $stmt = $conn->prepare($checkQuery);
            $stmt->bind_param("si", $username, $recordID);
            $stmt->execute();
            $result = $stmt->get_result();
            $count = $result->fetch_assoc()['user'];

            if ($count == 0 || $username === $_POST['original_username']) {
                // Hash the password
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                // Update query
                $updateQuery = "UPDATE users_tbl SET first_name = ?, last_name = ?, username = ?, password = ?, role = ? WHERE user_id = ?";

                $stmt = $conn->prepare($updateQuery);

                // Bind parameters
                $stmt->bind_param("ssssii", $firstName, $lastName, $username, $hashedPassword, $role, $recordID);
                $stmt->execute();

                if ($stmt->affected_rows > 0) {
                    // Remove err parameter from the URL
                    $referer = $_SERVER["HTTP_REFERER"];
                    $url = parse_url($referer);
                    parse_str($url['query'], $params);
                    unset($params['err']);
                    $query = http_build_query($params);
                    $location = isset($url['path']) ? $url['path'] . '?' . $query : $referer . '?' . $query;

                    header("Location: " . $location);
                    exit();
                } else {
                    echo "Error updating user account: " . $stmt->error;
                }

                $stmt->close();
            } else {
                $referer = $_SERVER["HTTP_REFERER"];
                $url = parse_url($referer);

                // Check if 'err' parameter already exists in the query string
                if (isset($url['query'])) {
                    parse_str($url['query'], $params);
                    if (isset($params['err']) && $params['err'] == 1) {
                        // If 'err' parameter with value 1 already exists, do nothing
                        header("Location: " . $referer);
                        exit();
                    }
                }

                // Add 'err=1' to the query string
                $query = isset($url['query']) ? $url['query'] . '&err=1' : 'err=1';
                $location = isset($url['path']) ? $url['path'] . '?' . $query : $referer . '?' . $query;
                header("Location: " . $location);
                exit();

            }
        }



        $username = $conn->real_escape_string($_POST['form_username']);
        $firstName = $conn->real_escape_string($_POST['form_fName']);
        $lastName = $conn->real_escape_string($_POST['form_lName']);
        $password = $conn->real_escape_string($_POST['form_password']);
        $role = $_POST['form_role'];

        $checkQuery = "SELECT COUNT(*) AS user FROM users_tbl WHERE username = ?";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $count = $result->fetch_assoc()['user'];

        if ($count == 0) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $insertQuery = "INSERT INTO users_tbl (first_name, last_name, username, password, role) VALUES (?, ?, ?, ?, ?)";

            $stmt = $conn->prepare($insertQuery);

            $stmt->bind_param("ssssi", $firstName, $lastName, $username, $hashedPassword, $role);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                // Remove 'err' parameter from the URL
                $referer = $_SERVER["HTTP_REFERER"];
                $url = parse_url($referer);
                if (isset($url['query'])) {
                    parse_str($url['query'], $params);
                    unset($params['err']);
                    $query = http_build_query($params);
                    $location = isset($url['path']) ? $url['path'] . '?' . $query : $referer . '?' . $query;
                } else {
                    $location = $referer;
                }

                header("Location: " . $location);
                exit();
            } else {
                echo "Error creating admin account: " . $stmt->error;
            }

            $stmt->close();
        } else {
            $referer = $_SERVER["HTTP_REFERER"];
            $url = parse_url($referer);

            // Check if 'err' parameter already exists in the query string
            if (isset($url['query'])) {
                parse_str($url['query'], $params);
                if (isset($params['err']) && $params['err'] == 1) {
                    // If 'err' parameter with value 1 already exists, do nothing
                    header("Location: " . $referer);
                    exit();
                }
            }

            // Add 'err=1' to the query string
            $query = isset($url['query']) ? $url['query'] . '&err=1' : 'err=1';
            $location = isset($url['path']) ? $url['path'] . '?' . $query : $referer . '?' . $query;
            header("Location: " . $location);
            exit();

        }
    }

} else {
    // Handle other requests (e.g., direct access to the script)
    echo <<<HTML
        <div style="text-align: center;">
            <h1 style="font-weight: bold;">OH NO!</h1>
            <h5>The page you're looking for does not exist, or has been moved</h5>
            <h6>Please return to <a href="/Inventory/?p=dashboard">Dashboard</a></h6>
        </div>
    HTML;
}