<?php
/*
    upload.php

    This file contains the function responsible for handling the uploading of images to a specified directory.

    Features:
    - Check for file errors during the upload process.
    - Generate a unique file name using the current date, time (down to milliseconds), and a random number.
    - Move the uploaded file to the specified directory.
    - Return the new file name on successful upload or false on failure.

    @param array $file The file to be uploaded from the global $_FILES array.
    @param string $uploadDirectory The directory where the file should be uploaded.
    @return string|bool Returns the new file name on success, or false on failure.

*/


function uploadPhoto($file, $uploadDirectory)
{
    // Check for file errors
    if ($file['error'] === 0) {
        // Get the file extension
        $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);

        // Generate a unique file name based on today's date, current time down to milliseconds, and a random number
        $date_time = date('Ymd_His') . '_' . round(microtime(true) * 1000) . '_';
        $unique_id = uniqid();
        $new_file_name = $date_time . $unique_id . '.' . $file_extension;

        // Move the uploaded file to the specified directory
        if (move_uploaded_file($file['tmp_name'], $uploadDirectory . $new_file_name)) {
            return $new_file_name;
        } else {
            return false; // Error uploading file
        }
    } else {
        return false; // File error
    }
}