<?php
/*
    POST_products.php

    This file handles the posting of products, including insertion, updating, and deletion of product records.
    It also manages file upload for product images.

    Features:
    - Insert new product records into the database.
    - Update existing product records in the database.
    - Delete product records from the database.
    - Upload product images and manage file paths.

*/

require_once ('../../required/db_conn.php');
require_once ('upload.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if it's a deletion request
    if (isset($_POST['delete_id'])) {
        // Handle deletion logic
        $delete_id = $_POST['delete_id'];

        // SQL query to fetch the image file path
        $fetch_image_query = "SELECT image FROM `products_tbl` WHERE `product_id` = ?";
        $fetch_image_stmt = $conn->prepare($fetch_image_query);
        $fetch_image_stmt->bind_param("i", $delete_id);
        $fetch_image_stmt->execute();
        $fetch_image_result = $fetch_image_stmt->get_result();

        if ($fetch_image_result->num_rows == 1) {
            $row = $fetch_image_result->fetch_assoc();
            $image_path = '../../' . $row['image'];

            // Delete the image file from the server
            if (file_exists($image_path)) {
                unlink($image_path);
            } else {
                echo "Image file not found.";
            }
        } else {
            echo "Product not found.";
        }

        // Close statement
        $fetch_image_stmt->close();

        // SQL query to delete a record from the supplier_tbl table
        $delete_query = "DELETE FROM `products_tbl` WHERE `product_id` = ?";
        $delete_stmt = $conn->prepare($delete_query);

        // Bind parameters
        $delete_stmt->bind_param("i", $delete_id);

        // Execute the statement
        if ($delete_stmt->execute()) {
            // Handle successful deletion
            echo "Record deleted successfully";
        } else {
            // Handle deletion failure
            echo "Error: " . $conn->error;
        }

        // Close statement
        $delete_stmt->close();
    } else {
        if ($_GET['action'] === 'update') {

            // Handle updating an existing record
            $recordID = $_POST['form_data_id'];
            $product = $conn->real_escape_string($_POST['form_product']);
            $category = $_POST['form_category'];
            $supplier = $_POST['form_supplier'];
            $buying_price = $_POST['form_buying_price'];
            $selling_price = $_POST['form_selling_price'];

            // SQL query to update an existing record in the supplier_tbl table

            $update_query = "UPDATE `products_tbl` SET 
                `product_name` = ?, 
                `category_id` = ?, 
                `supplier_id` = ?, 
                `buying_price` = ?, 
                `selling_price` = ?
            WHERE `product_id` = ?";

            // Prepare the statement
            $update_stmt = $conn->prepare($update_query);

            // Bind parameters
            $update_stmt->bind_param("sisiii", $product, $category, $supplier, $buying_price, $selling_price, $recordID);


            // Execute the statement
            if ($update_stmt->execute()) {
                // Handle successful update
                header("Location: " . $_SERVER["HTTP_REFERER"]);
                exit();
            } else {
                // Handle update failure
                echo "Error: " . $conn->error;
            }

            // Close statement
            $update_stmt->close();
            exit();
        }

        // Handle adding new record logic
        $product = $conn->real_escape_string($_POST['form_product']);
        $category = $_POST['form_category'];
        $supplier = $_POST['form_supplier'];
        $buying_price = $_POST['form_buying_price'];
        $selling_price = $_POST['form_selling_price'];

        if (isset($_FILES['form_image'])) {
            $uploaded_file_name = uploadPhoto($_FILES['form_image'], "../../uploads/");

            if ($uploaded_file_name) {
                $directory = "uploads/" . $uploaded_file_name;

                // SQL query to insert a new record into the supplier_tbl table
                $insert_query = "INSERT INTO `products_tbl` 
                                (`product_name`, `category_id`, `supplier_id`, `selling_price`, `buying_price`, `image`) 
                                VALUES 
                                (?, ?, ?, ?, ?, ?)";

                // Prepare the statement
                $add_stmt = $conn->prepare($insert_query);

                // Bind parameters
                $add_stmt->bind_param("siiiis", $product, $category, $supplier, $selling_price, $buying_price, $directory);

                // Execute the statement
                if ($add_stmt->execute()) {
                    // Handle successful insertion
                    header("Location: " . $_SERVER["HTTP_REFERER"]);
                    exit();
                } else {
                    // Handle insertion failure
                    echo "Error: " . $conn->error;
                }

                // Close statement
                $add_stmt->close();
                exit();
            } else {
                echo "Error uploading file.";
            }
        } else {
            echo "File not found.";
        }
    }
} else {
    // Handle other requests (e.g., direct access to the script)
    echo <<<HTML
        <div style="text-align: center;">
            <h1 style="font-weight: bold;">OH NO!</h1>
            <h5>The page you're looking for does not exist, or has been moved</h5>
            <h6>Please return to <a href="/Inventory/?p=dashboard">Dashboard</a></h6>
        </div>
    HTML;
}