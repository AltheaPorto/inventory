/*
    populateDropdown Function

    This function populates a dropdown/select element with options based on the provided data.
    It sorts the data alphabetically by the specified text field before populating the dropdown.
    The dropdown is emptied first, then a default option ("Select") is added, followed by appending options from the data.

    @param {jQuery} dropdown - The jQuery object representing the dropdown/select element.
    @param {Array} data - An array of objects containing the data to populate the dropdown.
    @param {string} valueField - The field name in each object representing the value of the option.
    @param {string} textField - The field name in each object representing the text of the option.

    @returns {void}

*/

function populateDropdown(dropdown, data, valueField, textField) {
	// Sort the data
	data = data.sort((a, b) => a[textField].localeCompare(b[textField]));

	// Empty the dropdown
	dropdown.empty();

	// Add the default option
	dropdown.append('<option value="" selected hidden>Select</option>');

	// Loop through the data and append each option
	data.forEach((item) => {
		dropdown.append(
			$('<option>', {
				value: item[valueField],
				text: item[textField],
			})
		);
	});
}
