/*
    tbl_products.js

    This script initializes the DataTable for displaying products records.
    It makes an AJAX request to fetch data from the server and populates the table accordingly.
    The table is designed to be responsive and supports various functionalities such as copying, exporting, and printing the table data.

    Features:
    - AJAX request to fetch products data from the server.
    - Displays products data in a responsive table.
    - Custom rendering for image previews.
    - Stock status indicator with different badges for low stock, stocked, and out of stock.
    - Column definitions and priority settings for responsiveness.
    - Additional buttons for copying, exporting, and printing table data.
    - Custom message for empty table.
    - Edit and delete buttons for each product record.

*/

$('#suppliers_tbl').DataTable({
	ajax: 'pages/requests/GET_data.php?data=products',
	responsive: true,
	language: {
		emptyTable: 'No products found in the records.',
	},
	columns: [
		{ data: 'product_id' },
		{
			data: 'image',
			render: function (data, type, row, meta) {
				return `<img src="${data}" class="img-thumbnail" data-bs-toggle="modal" data-bs-target="#modal_image_preview" role="button" onclick="preview(this)"/>`;
			},
		},
		{ data: 'product_name' },
		{ data: 'category' },
		{ data: 'supplier' },
		{ data: 'buying_price' },
		{ data: 'selling_price' },
		{
			data: null,
			render: function (data, type, row, meta) {
				if (parseInt(row.stock_value) > '0') {
					if (row.stock_value <= parseInt(row.initial_stock) * 0.1) {
						return `<span class="badge rounded-pill bg-warning text-dark">Low Stock</span>`;
					} else {
						return `<span class="badge rounded-pill bg-success">Stocked</span>`;
					}
				} else {
					return `<span class="badge rounded-pill bg-danger">Out of stock</span>`;
				}
			},
		},
		{ data: 'created_at' },
		{
			data: null,
			render: function (data, type, row, meta) {
				return `<button class="btn btn-success btn-sm" onclick="editRecord(${row.product_id})" data-bs-toggle="modal" data-bs-target="#editSuppliersModal">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="deleteRecord(${row.product_id})"  data-bs-toggle="modal" data-bs-target="#deleteModal">
                            <i class="fa-solid fa-trash"></i>
                        </button>`;
			},
		},
	],
	columnDefs: [
		{
			targets: '_all',
			className: 'text-center',
		},
		{ responsivePriority: 1, targets: 0 },
		{ responsivePriority: 2, targets: -1 },
	],
	layout: {
		topStart: {
			buttons: [
				{
					extend: 'copy',
					className: 'btn btn-sm btn-primary',
					titleAttr: 'Copy Table in clipboard',
					text: '<i class="fa-solid fa-copy me-2"></i>Copy',
					init: function (api, node, config) {
						$(node).removeClass('dt-button');
					},
				},
				{
					extend: 'csv',
					className: 'btn btn-sm btn-primary',
					titleAttr: 'Export Table as CSV',
					text: '<i class="fa-solid fa-file-csv me-2"></i>CSV',
					init: function (api, node, config) {
						$(node).removeClass('dt-button');
					},
				},
				{
					extend: 'print',
					className: 'btn btn-sm btn-primary',
					titleAttr: 'Print Table',
					text: '<i class="fa-solid fa-print me-2"></i>Print',
					init: function (api, node, config) {
						$(node).removeClass('dt-button');
					},
				},
			],
		},
	},
	drawCallback: function (settings) {
		$('#loader_container').fadeOut();
	},
});
