/*
    tbl_suppliers.js

    This script initializes the DataTable for displaying suppliers records.
    It makes an AJAX request to fetch data from the server and populates the table accordingly.
    The table is designed to be responsive and supports various functionalities such as copying, exporting, and printing the table data.

    Features:
    - AJAX request to fetch suppliers data from the server.
    - Displays suppliers data in a responsive table.
    - Custom rendering for address fields, including province, municipality, and barangay.
    - Conditional rendering of edit and delete buttons based on user role.
    - Column definitions and priority settings for responsiveness.
    - Additional buttons for copying, exporting, and printing table data.
    - Custom message for empty table.

*/

$('#suppliers_tbl').DataTable({
	ajax: 'pages/requests/GET_data.php?data=supplier',
	responsive: true,
	language: {
		emptyTable: 'No suppliers found in the records.',
	},
	columns: [
		{ data: 'supplier_id' },
		{ data: 'supplier_name' },
		{ data: 'coordinator_name' },
		{
			data: null,
			render: function (data, type, row, meta) {
				const province = capitalize_first_letter(
					Philippines.provinces.find(
						(province) => province.prov_code === row.province_id.toString()
					).name
				);

				const municipality = capitalize_first_letter(
					Philippines.getCityMunByProvince(row.province_id.toString()).find(
						(municipality) =>
							municipality.mun_code === row.municipality_id.toString()
					).name
				);

				const barangay = row.barangay_id;
				const address = row.address;

				return `${address}, Brgy. ${barangay}, ${municipality}, ${province}`;
			},
		},
		{ data: 'formatted_phone_number' },
		{ data: 'formatted_created_at' },
		{
			data: null,
			render: function (data, type, row, meta) {
				if (ROLE_PLACEHOLDER !== 2) {
					return `<button class="btn btn-success btn-sm" onclick="editRecord(${row.supplier_id})" data-bs-toggle="modal" data-bs-target="#editSuppliersModal">
								<i class="fa-solid fa-pen-to-square"></i>
							</button>
							<button class="btn btn-danger btn-sm" onclick="deleteRecord(${row.supplier_id})"  data-bs-toggle="modal" data-bs-target="#deleteModal">
								<i class="fa-solid fa-trash"></i>
							</button>`;
				} else {
					return `<button class="btn btn-success btn-sm" onclick="editRecord(${row.supplier_id})" data-bs-toggle="modal" data-bs-target="#editSuppliersModal">
								<i class="fa-solid fa-pen-to-square"></i>
							</button>`;
				}
			},
		},
	],
	columnDefs: [
		{
			targets: '_all',
			className: 'text-center',
		},
		{ responsivePriority: 1, targets: 0 },
		{ responsivePriority: 2, targets: -1 },
	],
	layout: {
		topStart: {
			buttons: [
				{
					extend: 'copy',
					className: 'btn btn-sm btn-primary',
					titleAttr: 'Copy Table in clipboard',
					text: '<i class="fa-solid fa-copy me-2"></i>Copy',
					init: function (api, node, config) {
						$(node).removeClass('dt-button');
					},
				},
				{
					extend: 'csv',
					className: 'btn btn-sm btn-primary',
					titleAttr: 'Export Table as CSV',
					text: '<i class="fa-solid fa-file-csv me-2"></i>CSV',
					init: function (api, node, config) {
						$(node).removeClass('dt-button');
					},
				},
				{
					extend: 'print',
					className: 'btn btn-sm btn-primary',
					titleAttr: 'Print Table',
					text: '<i class="fa-solid fa-print me-2"></i>Print',
					init: function (api, node, config) {
						$(node).removeClass('dt-button');
					},
				},
			],
		},
	},
	drawCallback: function (settings) {
		$('#loader_container').fadeOut();
	},
});
