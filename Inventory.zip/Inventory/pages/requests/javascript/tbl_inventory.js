/*
    tbl_inventory.js

    This script initializes the DataTable for displaying inventory records.
    It makes an AJAX request to fetch data from the server and populates the table accordingly.
    The table is designed to be responsive and supports various functionalities such as copying, exporting, and printing the table data.

    Features:
    - AJAX request to fetch inventory data from the server.
    - Displays inventory data in a responsive table.
    - Custom rendering for image previews and action buttons.
    - Column definitions and priority settings for responsiveness.
    - Additional buttons for copying, exporting, and printing table data.
    - Custom message for empty table.

*/

$('#inventory_tbl').DataTable({
	ajax: 'pages/requests/GET_data.php?data=inventory',
	responsive: true,
	language: {
		emptyTable: 'No inventory record found.',
	},
	columns: [
		{
			data: 'image',
			render: function (data, type, row, meta) {
				return `<img src="${data}" class="img-thumbnail w-25" data-bs-toggle="modal" data-bs-target="#modal_image_preview" role="button" onclick="preview(this)"/>`;
			},
		},
		{ data: 'product_name' },
		{ data: 'quantity' },
		{ data: 'unit' },
		{ data: 'restock_date' },
		// {
		// 	data: null,
		// 	render: function (data, type, row, meta) {
		// 		return `<button class="btn btn-danger btn-sm" onclick="deleteRecord(${row.restock_id})"  data-bs-toggle="modal" data-bs-target="#deleteModal">
		// 					<i class="fa-solid fa-trash"></i>
		// 				</button>`;
		// 	},
		// },
	],
	columnDefs: [
		{
			targets: '_all',
			className: 'text-center',
		},
		{ targets: 0, className: 'col-lg-2' },
		{ responsivePriority: 1, targets: 0 },
		{ responsivePriority: 2, targets: -1 },
	],
	layout: {
		topStart: {
			buttons: [
				{
					extend: 'copy',
					className: 'btn btn-sm btn-primary',
					titleAttr: 'Copy Table in clipboard',
					text: '<i class="fa-solid fa-copy me-2"></i>Copy',
					init: function (api, node, config) {
						$(node).removeClass('dt-button');
					},
				},
				{
					extend: 'csv',
					className: 'btn btn-sm btn-primary',
					titleAttr: 'Export Table as CSV',
					text: '<i class="fa-solid fa-file-csv me-2"></i>CSV',
					init: function (api, node, config) {
						$(node).removeClass('dt-button');
					},
				},
				{
					extend: 'print',
					className: 'btn btn-sm btn-primary',
					titleAttr: 'Print Table',
					text: '<i class="fa-solid fa-print me-2"></i>Print',
					init: function (api, node, config) {
						$(node).removeClass('dt-button');
					},
				},
			],
		},
	},
	drawCallback: function (settings) {
		$('#loader_container').fadeOut();
	},
});
