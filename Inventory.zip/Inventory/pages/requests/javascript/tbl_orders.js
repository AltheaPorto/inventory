/*
    orders.js

    This script initializes the DataTable for displaying orders records.
    It makes an AJAX request to fetch data from the server and populates the table accordingly.
    The table is designed to be responsive and supports various functionalities such as copying, exporting, and printing the table data.

    Features:
    - AJAX request to fetch orders data from the server.
    - Displays orders data in a responsive table.
    - Custom rendering for image previews.
    - Column definitions and priority settings for responsiveness.
    - Additional buttons for copying, exporting, and printing table data.
    - Custom message for empty table.
    - Default ordering by the first column in descending order.

*/

$('#inventory_tbl').DataTable({
	ajax: 'pages/requests/GET_data.php?data=orders',
	responsive: true,
	language: {
		emptyTable: 'No orders at the moment.',
	},
	columns: [
		{ data: 'order_id' },
		{
			data: 'image',
			render: function (data, type, row, meta) {
				console.log(row);
				return `<img src="${data}" class="img-thumbnail" data-bs-toggle="modal" data-bs-target="#modal_image_preview" role="button" onclick="preview(this)"/>`;
			},
		},
		{ data: 'product_name' },
		{ data: 'selling_price' },
		{ data: 'quantity' },
		{ data: 'total_price' },
		{ data: 'category' },
		{ data: 'supplier' },
		{ data: 'name' },
		{ data: 'order_date' },
	],
	columnDefs: [
		{
			targets: '_all',
			className: 'text-center',
		},
		{ targets: 0, className: 'col-lg-2' },
		{ responsivePriority: 1, targets: 0 },
		{ responsivePriority: 2, targets: -1 },
	],
	layout: {
		topStart: {
			buttons: [
				{
					extend: 'copy',
					className: 'btn btn-sm btn-primary',
					titleAttr: 'Copy Table in clipboard',
					text: '<i class="fa-solid fa-copy me-2"></i>Copy',
					init: function (api, node, config) {
						$(node).removeClass('dt-button');
					},
				},
				{
					extend: 'csv',
					className: 'btn btn-sm btn-primary',
					titleAttr: 'Export Table as CSV',
					text: '<i class="fa-solid fa-file-csv me-2"></i>CSV',
					init: function (api, node, config) {
						$(node).removeClass('dt-button');
					},
				},
				{
					extend: 'print',
					className: 'btn btn-sm btn-primary',
					titleAttr: 'Print Table',
					text: '<i class="fa-solid fa-print me-2"></i>Print',
					init: function (api, node, config) {
						$(node).removeClass('dt-button');
					},
				},
			],
		},
	},
	drawCallback: function (settings) {
		$('#loader_container').fadeOut();
	},
	order: [[0, 'desc']],
});
