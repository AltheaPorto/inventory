<?php

/*
    GET_user_dashboard.php

    This file handles AJAX requests for fetching products and related information for the user account dashboard.
    It supports sorting products by various options and searching for specific products.

    Features:
    - Retrieves products from the products_tbl table along with their computed stock values.
    - Supports sorting products by latest, price (low to high), and price (high to low).
    - Enables searching for products based on the search term and filtering by category.
    - Utilizes SQL queries to fetch data efficiently from the database.
    - Outputs the retrieved product information in JSON format for consumption by frontend components.

*/

$sortOption = isset($_GET['sort']) ? $_GET['sort'] : 'oldest';
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';
$category = isset($_GET['category']) ? $_GET['category'] : '';

switch ($sortOption) {
    case 'latest':
        $orderBy = 'p.created_at DESC';
        break;
    case 'low-high':
        $orderBy = 'p.selling_price ASC';
        break;
    case 'high-low':
        $orderBy = 'p.selling_price DESC';
        break;
    default:
        $sortOption = "oldest";
        $orderBy = 'p.created_at ASC'; // Default to sorting by the oldest
}

// Fetch products along with their computed stock values and ordered by the selected sorting option
$sql = "SELECT 
            p.product_id, 
            p.initial_stock,
            p.image, 
            p.product_name, 
            p.stock_value,
            FORMAT(p.selling_price, 2) AS price, 
            c.category_name
        FROM 
            products_tbl p 
        LEFT JOIN 
            restock_tbl r ON p.product_id = r.product_id 
        JOIN 
            categories_tbl c ON p.category_id = c.category_id 
        WHERE 1 "; // Start of WHERE clause

if (!empty($searchTerm)) {
    $sql .= " AND p.product_name LIKE '%" . $conn->real_escape_string($searchTerm) . "%' ";
}

if (!empty($category)) {
    $sql .= " AND c.category_id = '" . $conn->real_escape_string($category) . "'";
}

$sql .= " GROUP BY 
            p.product_id, 
            p.image, 
            p.product_name, 
            p.selling_price, 
            c.category_name 
        ORDER BY 
            stock_value DESC, 
            $orderBy";
// Execute the query

$result = $conn->query($sql);
