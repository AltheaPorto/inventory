<?php

/*
    POST_Credentials.php

    This file handles the login process by validating the user's credentials against the database.
    It processes the information provided during login and initiates a session for authenticated users.

    Features:
    - Validates username and password from the login form.
    - Queries the database to check if the provided username exists.
    - Verifies the provided password against the stored hashed password.
    - Updates the user's last login timestamp on successful login.
    - Sets session variables for the authenticated user.
    - Redirects to the homepage on successful login or back to the login page with an error parameter on failure.

*/


require_once ('../../required/db_conn.php');
session_start();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate username and password (you can add more robust validation)
    $username = $_POST['form_email']; // Assuming the form field name is form_email
    $password = $_POST['form_password']; // Assuming the form field name is form_password

    // Perform database query to check username and password (you may need to adjust this query)
    $query = "SELECT * FROM users_tbl WHERE username = ? LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $updateQuery = "UPDATE users_tbl SET last_login = CURRENT_TIMESTAMP WHERE user_id = ?";
            $updateStmt = $conn->prepare($updateQuery);
            $updateStmt->bind_param("i", $user['user_id']);
            $updateStmt->execute();

            // Set session variables
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            header("Location: ../../index.php");
            exit();
        }
    }

    // Redirect to login page with error parameter
    header("Location: ../../index.php?err=1");
    exit();
}
