<?php

/*
    GET_data.php

    This file handles AJAX requests for fetching all records stored in a specific database table.

    Features:
    - Retrieves all records from the specified table in the database.
    - Supports various tables including suppliers, categories, products, users, inventory, and orders.
    - Utilizes SQL queries to fetch data efficiently from the database.
    - Outputs the retrieved records in JSON format for consumption by frontend components.

*/

require_once ('../../required/db_conn.php');

if (isset($_GET['data'])) {

    $data = $_GET['data'];

    switch ($data) {
        case 'supplier':
            // SQL query to fetch data from the supplier_tbl table
            $sql = "SELECT 
                    supplier_id,
                    supplier_name,
                    coordinator_name,
                    CONCAT(
                        SUBSTRING(phone, 1, 4), ' (',
                        SUBSTRING(phone, 5, 3), ') ',
                        SUBSTRING(phone, 8)
                    ) AS formatted_phone_number,
                    province_id,
                    municipality_id,
                    barangay_id,
                    address,
                    DATE_FORMAT(created_at, '%M %e, %Y') AS formatted_created_at
                FROM 
                    supplier_tbl;
                ";
            break;
        case 'categories':
            $sql = "SELECT * FROM categories_tbl";
            break;
        case 'products':
            $sql = "SELECT 
                        p.product_id,
                        p.product_name,
                        p.image,
                        p.stock_value,
                        p.initial_stock,
                        c.category_name AS category,
                        s.supplier_name AS supplier,
                        CONCAT('₱ ', FORMAT(p.buying_price, 2)) AS buying_price,
                        CONCAT('₱ ', FORMAT(p.selling_price, 2)) AS selling_price,
                        DATE_FORMAT(p.created_at, '%M %d, %Y ') AS created_at
                    FROM 
                        products_tbl p
                    JOIN 
                        categories_tbl c ON p.category_id = c.category_id
                    JOIN 
                        supplier_tbl s ON p.supplier_id = s.supplier_id;
                    ";
            break;
        case 'users':
            $sql = "SELECT
                        u.user_id,
                        CONCAT(u.first_name, ' ', u.last_name) AS name,
                        u.username,
                        u.status,
                        CASE u.role
                            WHEN 0 THEN 'Admin'
                            WHEN 1 THEN 'User'
                            WHEN 2 THEN 'Employee'
                            ELSE 'Unknown'
                        END AS role,
                        IFNULL(DATE_FORMAT(u.last_login, '%M %d, %Y, %l:%i:%s %p'), 'HAS NOT LOGGED IN') AS last_login_formatted,
                        DATE_FORMAT(u.created_at, '%M %d, %Y') AS created_at
                    FROM users_tbl u";
            break;
        case 'inventory':
            $sql = "SELECT 
                        r.product_id,
                        p.product_name,
                        p.image,
                        DATE_FORMAT(MAX(r.restock_date), '%b %d, %Y, %h:%i:%s %p') AS restock_date,
                        (SELECT r_inner.unit 
                        FROM restock_tbl r_inner 
                        WHERE r_inner.product_id = r.product_id 
                        ORDER BY r_inner.restock_date DESC 
                        LIMIT 1) AS unit,
                        SUM(r.quantity) AS quantity
                    FROM 
                        restock_tbl r
                    INNER JOIN 
                        products_tbl p ON r.product_id = p.product_id
                    GROUP BY 
                        r.product_id
                    ORDER BY 
                        restock_date DESC;
                    ";
            break;

        case 'orders':
            $sql = "SELECT 
                        o.order_id,
                        CONCAT(u.first_name, ' ', u.last_name) AS name,
                        p.image,
                        CONCAT('₱ ', FORMAT(p.selling_price, 2)) AS selling_price,
                        CONCAT('₱ ', FORMAT(p.selling_price * o.quantity, 2)) AS total_price,
                        p.product_name AS product_name,
                        c.category_name AS category,
                        s.supplier_name AS supplier,
                        CONCAT('x', o.quantity) AS quantity,
                        DATE_FORMAT(o.created_at, '%M %d, %Y - %h:%i %p') AS order_date
                    FROM 
                        orders_tbl AS o
                    JOIN 
                        users_tbl AS u ON o.user_id = u.user_id
                    JOIN 
                        products_tbl AS p ON o.product_id = p.product_id
                    JOIN 
                        categories_tbl AS c ON p.category_id = c.category_id
                    JOIN 
                        supplier_tbl AS s ON p.supplier_id = s.supplier_id";

            break;
        case 'order_users':
            session_start();
            $sql = "SELECT 
                        o.order_id,
                        CONCAT(u.first_name, ' ', u.last_name) AS name,
                        p.image,
                        CONCAT('₱ ', FORMAT(p.selling_price, 2)) AS selling_price,
                        CONCAT('₱ ', FORMAT(p.selling_price * o.quantity, 2)) AS total_price,
                        p.product_name AS product_name,
                        c.category_name AS category,
                        s.supplier_name AS supplier,
                        CONCAT('x', o.quantity) AS quantity,
                        DATE_FORMAT(o.created_at, '%M %d, %Y - %h:%i %p') AS order_date
                    FROM 
                        orders_tbl AS o
                    JOIN 
                        users_tbl AS u ON o.user_id = u.user_id
                    JOIN 
                        products_tbl AS p ON o.product_id = p.product_id
                    JOIN 
                        categories_tbl AS c ON p.category_id = c.category_id
                    JOIN 
                        supplier_tbl AS s ON p.supplier_id = s.supplier_id
                    WHERE
                        u.user_id = " . $_SESSION['user_id'];
            break;
        default:
            echo json_encode(array("data" => array()));
            exit();
    }

    // Execute query
    $result = $conn->query($sql);

    // Check if any rows were returned
    if ($result->num_rows > 0) {
        // Fetch associative array of the result
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        // Convert data to JSON format
        echo json_encode(array("data" => $data));
    } else {
        // No rows returned
        echo json_encode(array("data" => array())); // Return empty JSON array
    }


}



