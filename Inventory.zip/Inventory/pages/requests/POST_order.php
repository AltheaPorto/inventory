<?php

/*
    POST_orders.php

    This file handles the recording of orders in the orders_tbl table.
    It allows users to place orders for products, updating the stock value accordingly.

    Features:
    - Inserts orders into the database.
    - Updates the stock value of products after an order is placed.
    - Provides error messages for any failures during the order placement process.

*/

session_start();
require_once ('../../required/db_conn.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product = $_POST['form_data_id'];
    $quantity = $_POST['form_quantity'];
    $user = $_SESSION['user_id'];

    // Prepare and bind the SQL statement to insert the order
    $sql_insert_order = "INSERT INTO orders_tbl (user_id, product_id, quantity) VALUES (?, ?, ?)";
    $stmt_insert_order = $conn->prepare($sql_insert_order);
    $stmt_insert_order->bind_param("iii", $user, $product, $quantity);

    // Execute the insert statement
    if ($stmt_insert_order->execute()) {
        // Order inserted successfully, now update the stock value in products table
        $sql_update_stock = "UPDATE products_tbl SET stock_value = stock_value - ? WHERE product_id = ?";
        $stmt_update_stock = $conn->prepare($sql_update_stock);
        $stmt_update_stock->bind_param("ii", $quantity, $product);

        // Execute the update statement
        if ($stmt_update_stock->execute()) {
            // Stock updated successfully
            header("Location: " . $_SERVER["HTTP_REFERER"]);
            exit();
        } else {
            // Error updating stock value
            echo "Error updating stock value: " . $conn->error;
        }

        // Close update statement
        $stmt_update_stock->close();
    } else {
        // Error occurred while inserting order
        echo "Error placing order: " . $conn->error;
    }

    // Close insert order statement
    $stmt_insert_order->close();
    // Close connection
    $conn->close();
} else {
    // Handle other requests (e.g., direct access to the script)
    echo <<<HTML
        <div style="text-align: center;">
            <h1 style="font-weight: bold;">OH NO!</h1>
            <h5>The page you're looking for does not exist, or has been moved</h5>
            <h6>Please return to <a href="/Inventory/?p=dashboard">Dashboard</a></h6>
        </div>
    HTML;
}
