<?php
/*
    logout.php

    This file handles user logout by unsetting and destroying all session variables, then redirecting the user to the login page.

    Features:
    - Destroys the user session, ensuring logout functionality.
    - Redirects the user to the login page after logout.
    - Provides a simple and secure way to handle user logout in the application.

*/

// Start the session
session_start();

// Unset all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to the login page
header("Location: ../../index.php");
exit();