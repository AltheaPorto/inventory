<?php
/*
    post_suppliers.php

    This file handles the posting of supplier information, including insertion, updating, and deletion of supplier records.

    Features:
    - Insert new supplier records into the supplier_tbl table.
    - Update existing supplier records in the supplier_tbl table.
    - Delete supplier records from the supplier_tbl table.

*/

require_once ('../../required/db_conn.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if it's a deletion request
    if (isset($_POST['delete_id'])) {
        // Handle deletion logic
        $delete_id = $_POST['delete_id'];

        // SQL query to delete a record from the supplier_tbl table
        $delete_query = "DELETE FROM `supplier_tbl` WHERE `supplier_id` = ?";

        // Prepare the statement
        $delete_stmt = $conn->prepare($delete_query);

        // Bind parameters
        $delete_stmt->bind_param("i", $delete_id);

        // Execute the statement
        if ($delete_stmt->execute()) {
            // Handle successful deletion
            echo "Record deleted successfully";
        } else {
            // Handle deletion failure
            echo "Error: " . $conn->error;
        }

        // Close statement
        $delete_stmt->close();
    } else {
        if ($_GET['action'] === 'update') {

            // Handle updating an existing record
            $recordID = $_POST['form_data_id'];
            $supplier = $conn->real_escape_string($_POST['form_supplier']);
            $coordinator = $conn->real_escape_string($_POST['form_coordinator']);
            $province = $conn->real_escape_string($_POST['form_province']);
            $municipality = $conn->real_escape_string($_POST['form_municipality']);
            $barangay = $conn->real_escape_string($_POST['form_barangay']);
            $phone = $conn->real_escape_string($_POST['form_phone']);
            $address = $conn->real_escape_string($_POST['form_address']);

            // SQL query to update an existing record in the supplier_tbl table
            $update_query = "UPDATE `supplier_tbl` SET 
                `supplier_name` = ?, 
                `coordinator_name` = ?, 
                `province_id` = ?, 
                `municipality_id` = ?, 
                `barangay_id` = ?, 
                `address` = ?, 
                `phone` = ?
                WHERE `supplier_id` = ?";

            echo "SQL Query: " . $update_query;

            // Prepare the statement
            $update_stmt = $conn->prepare($update_query);

            $update_stmt->bind_param("sssssssi", $supplier, $coordinator, $province, $municipality, $barangay, $address, $phone, $recordID);

            // Execute the statement
            if ($update_stmt->execute()) {
                // Handle successful update
                header("Location: " . $_SERVER["HTTP_REFERER"]);
                exit();
            } else {
                // Handle update failure
                echo "Error: " . $conn->error;
            }


            // Bind parameters

            // Close statement
            $update_stmt->close();
            exit();
        }

        // Handle adding new record logic
        $supplier = $conn->real_escape_string($_POST['form_supplier']);
        $coordinator = $conn->real_escape_string($_POST['form_coordinator']);
        $province = $conn->real_escape_string($_POST['form_province']);
        $municipality = $conn->real_escape_string($_POST['form_municipality']);
        $barangay = $conn->real_escape_string($_POST['form_barangay']);
        $address = $conn->real_escape_string($_POST['form_address']);
        $phone = $conn->real_escape_string($_POST['form_phone']);


        // SQL query to insert a new record into the supplier_tbl table
        $insert_query = "INSERT INTO `supplier_tbl` 
                        (`supplier_name`, `coordinator_name`, `province_id`, `municipality_id`, `barangay_id`, `address`, `phone`) 
                        VALUES 
                        (?, ?, ?, ?, ?, ?, ?)";

        // Prepare the statement
        $add_stmt = $conn->prepare($insert_query);

        // Bind parameters
        $add_stmt->bind_param("sssssss", $supplier, $coordinator, $province, $municipality, $barangay, $address, $phone);

        // Execute the statement
        if ($add_stmt->execute()) {
            // Handle successful insertion
            header("Location: " . $_SERVER["HTTP_REFERER"]);
            exit();
        } else {
            // Handle insertion failure
            echo "Error: " . $conn->error;
        }

        // Close statement
        $add_stmt->close();
    }

} else {
    // Handle other requests (e.g., direct access to the script)
    echo <<<HTML
        <div style="text-align: center;">
            <h1 style="font-weight: bold;">OH NO!</h1>
            <h5>The page you're looking for does not exist, or has been moved</h5>
            <h6>Please return to <a href="/Inventory/?p=dashboard">Dashboard</a></h6>
        </div>
    HTML;
}
?>