<?php
/*
    post_stock.php

    This file handles the posting of stock information, including insertion, updating, and deletion of restock records.
    It also manages stock value updates in the products table.

    Features:
    - Insert new restock records into the restock_tbl table.
    - Update stock values in the products_tbl table based on restock operations.
    - Delete restock records from the restock_tbl table.

*/

require_once ('../../required/db_conn.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if it's a deletion request
    if (isset($_POST['delete_id'])) {
        // Handle deletion logic
        $delete_id = $_POST['delete_id'];

        // SQL query to delete a record from the supplier_tbl table
        $delete_query = "DELETE FROM `restock_tbl` WHERE `restock_id` = ?";

        // Prepare the statement
        $delete_stmt = $conn->prepare($delete_query);

        // Bind parameters
        $delete_stmt->bind_param("i", $delete_id);

        // Execute the statement
        if ($delete_stmt->execute()) {
            // Handle successful deletion
            echo "Record deleted successfully";
        } else {
            // Handle deletion failure
            echo "Error: " . $conn->error;
        }

        // Close statement
        $delete_stmt->close();
    } else {
        if ($_GET['action'] === 'update') {

            // Handle updating an existing record
            $recordID = $_POST['form_data_id'];
            $supplier = $conn->real_escape_string($_POST['form_supplier']);
            $coordinator = $conn->real_escape_string($_POST['form_coordinator']);
            $province = $conn->real_escape_string($_POST['form_province']);
            $municipality = $conn->real_escape_string($_POST['form_municipality']);
            $barangay = $conn->real_escape_string($_POST['form_barangay']);
            $phone = $conn->real_escape_string($_POST['form_phone']);
            $address = $conn->real_escape_string($_POST['form_address']);

            // SQL query to update an existing record in the supplier_tbl table
            $update_query = "UPDATE `supplier_tbl` SET 
                `supplier_name` = ?, 
                `coordinator_name` = ?, 
                `province_id` = ?, 
                `municipality_id` = ?, 
                `barangay_id` = ?, 
                `address` = ?, 
                `phone` = ?
                WHERE `supplier_id` = ?";

            echo "SQL Query: " . $update_query;

            // Prepare the statement
            $update_stmt = $conn->prepare($update_query);

            $update_stmt->bind_param("sssssssi", $supplier, $coordinator, $province, $municipality, $barangay, $address, $phone, $recordID);

            // Execute the statement
            if ($update_stmt->execute()) {
                // Handle successful update
                header("Location: " . $_SERVER["HTTP_REFERER"]);
                exit();
            } else {
                // Handle update failure
                echo "Error: " . $conn->error;
            }


            // Bind parameters

            // Close statement
            $update_stmt->close();
            exit();
        }

        // Handle adding new record logic
        $product = $conn->real_escape_string($_POST['form_product']);
        $quantity = $conn->real_escape_string($_POST['form_quantity']);
        $unit = $conn->real_escape_string($_POST['form_unit']);

        // Start a transaction
        $conn->begin_transaction();

        try {
            // Get current stock and initial stock
            $get_stock_query = "SELECT initial_stock, stock_value FROM products_tbl WHERE product_id = ?";
            $get_stock_stmt = $conn->prepare($get_stock_query);
            $get_stock_stmt->bind_param("i", $product);
            $get_stock_stmt->execute();
            $get_stock_result = $get_stock_stmt->get_result();
            $stock_row = $get_stock_result->fetch_assoc();
            $initial_stock = $stock_row['initial_stock'];
            $stock_value = $stock_row['stock_value'];

            // Update initial stock and current stock when adding a new product
            if ($initial_stock == 0 && $stock_value == 0) {
                $initial_stock = $quantity;
                $stock_value = $quantity;
            } else {
                // Update current stock when restocking
                $initial_stock += $stock_value + $quantity;
                $stock_value += $quantity;
            }

            // Update stock values in products_tbl
            $update_query = "UPDATE products_tbl SET initial_stock = ?, stock_value = ? WHERE product_id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("iii", $initial_stock, $stock_value, $product);
            $update_result = $update_stmt->execute();

            // Check if update was successful
            if (!$update_result) {
                throw new Exception("Error updating stock values: " . $conn->error);
            }

            // Insert record into restock_tbl
            $insert_query = "INSERT INTO restock_tbl (product_id, quantity, unit) VALUES (?, ?, ?)";
            $add_stmt = $conn->prepare($insert_query);
            $add_stmt->bind_param("iis", $product, $quantity, $unit);
            $add_result = $add_stmt->execute();

            // Check if insertion was successful
            if (!$add_result) {
                throw new Exception("Error adding inventory: " . $conn->error);
            }

            // Commit transaction
            $conn->commit();

            // Redirect after successful addition
            header("Location: " . $_SERVER["HTTP_REFERER"]);
            exit();
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();

            // Handle error
            echo "Error: " . $e->getMessage();
        }

    }

} else {
    // Handle other requests (e.g., direct access to the script)
    echo <<<HTML
        <div style="text-align: center;">
            <h1 style="font-weight: bold;">OH NO!</h1>
            <h5>The page you're looking for does not exist, or has been moved</h5>
            <h6>Please return to <a href="/Inventory/?p=dashboard">Dashboard</a></h6>
        </div>
    HTML;
}
?>