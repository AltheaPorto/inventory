<?php
/*
    POST_categories.php

    This file handles the recording, updating, and deleting of records in the categories_tbl table.
    If the POST request contains a 'delete_id', it deletes the corresponding record.
    If the 'action' parameter is 'update', it updates the record with the provided information.
    Otherwise, it inserts a new record.

    Features:
    - Handles deletion of records based on the 'delete_id' parameter.
    - Updates records if the 'action' parameter is 'update'.
    - Inserts new records if neither 'delete_id' nor 'action' is present.
    - Redirects back to the previous page after successful operations.
    - Provides error messages for failure cases.

*/
require_once ('../../required/db_conn.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['delete_id'])) {
        // Handle deletion logic
        $delete_id = $_POST['delete_id'];

        // SQL query to delete a record from the supplier_tbl table
        $delete_query = "DELETE FROM `categories_tbl` WHERE `category_id` = ?";

        // Prepare the statement
        $delete_stmt = $conn->prepare($delete_query);

        // Bind parameters
        $delete_stmt->bind_param("i", $delete_id);

        // Execute the statement
        if ($delete_stmt->execute()) {
            // Handle successful deletion
            echo "Record deleted successfully";
        } else {
            // Handle deletion failure
            echo "Error: " . $conn->error;
        }

        // Close statement
        $delete_stmt->close();
    } else {
        if ($_GET['action'] === 'update') {

            $recordID = $_POST['form_data_id'];
            $category_name = $conn->real_escape_string($_POST['form_category']);
            $status = $conn->real_escape_string($_POST['form_status']);

            $update_query = "UPDATE `categories_tbl` SET 
                `category_name` = ?, 
                `status` = ? 
                WHERE `category_id` = ?";
            // Prepare the statement
            $update_stmt = $conn->prepare($update_query);

            $update_stmt->bind_param("ssi", $category_name, $status, $recordID);

            // Execute the statement
            if ($update_stmt->execute()) {
                // Handle successful update
                header("Location: " . $_SERVER["HTTP_REFERER"]);
                exit();
            } else {
                // Handle update failure
                echo "Error: " . $conn->error;
            }


            // Bind parameters

            // Close statement
            $update_stmt->close();
            exit();
        }

        // Handle adding new record logic
        $category_name = $conn->real_escape_string($_POST['form_category']);

        // SQL query to insert a new record into the supplier_tbl table
        $insert_query = "INSERT INTO `categories_tbl` (`category_name`) VALUES (?)";

        // Prepare the statement
        $add_stmt = $conn->prepare($insert_query);

        // Bind parameters
        $add_stmt->bind_param("s", $category_name);

        // Execute the statement
        if ($add_stmt->execute()) {
            // Handle successful insertion
            header("Location: " . $_SERVER["HTTP_REFERER"]);
            exit();
        } else {
            // Handle insertion failure
            echo "Error: " . $conn->error;
        }

        // Close statement
        $add_stmt->close();
    }

} else {
    // Handle other requests (e.g., direct access to the script)
    echo <<<HTML
        <div style="text-align: center;">
            <h1 style="font-weight: bold;">OH NO!</h1>
            <h5>The page you're looking for does not exist, or has been moved</h5>
            <h6>Please return to <a href="/Inventory/?p=dashboard">Dashboard</a></h6>
        </div>
    HTML;
}