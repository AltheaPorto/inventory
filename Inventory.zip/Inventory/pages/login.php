<!--
    index.html

    This HTML/PHP file serves as the login page for the StockSense Inventory Management System. It includes the following features:

    1. Sets up the document with the necessary meta tags for character encoding and viewport settings.
    2. Sets the page title and favicon images using constants defined in the PHP configuration file.
    3. Includes external resources such as Bootstrap 5 for styling and FontAwesome for icons, jQuery for JavaScript functionality, Chart.js for charts, and DataTables for table handling.
    4. Contains a login form that prompts users to enter their username and password.
    5. Displays an error message if login credentials are incorrect.

    HTML Structure:
    - The body contains a centered container with a login card.
    - The login card includes a logo, an error message, and a form for username and password input.
    - The form submits to a PHP script for credential validation.
-->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo APP_NAME ?></title>

    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo FAVICON_32 ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo FAVICON_16 ?>">

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap 5 -->
    <link href="assets/vendor/BS5/css/bootstrap.min.css" rel="stylesheet">
    <script src="assets/vendor/BS5/js/bootstrap.bundle.min.js"></script>

    <!-- FontAwesome 6.4.0 CSS -->
    <link rel="stylesheet" href="assets/vendor/FontAwesome6/all.min.css">

    <!-- JQuery Library -->
    <script src="assets/vendor/jQuery/jquery-3.7.0.min.js"></script>

    <!-- Custom JavaScript -->
    <script src="assets/scripts.js"></script>

    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/styles.css">

    <!-- Chart JS -->
    <script src="assets/vendor/chartJS/chart.js"></script>

    <!-- DataTables -->
    <link href="assets/vendor/DataTables/datatables.min.css" rel="stylesheet">
    <script src="assets/vendor/DataTables/datatables.min.js"></script>

</head>

<body>
    <div class="container d-flex align-items-center h-100">
        <div class="row w-100">
            <div class="mx-auto col-12 col-lg-7">
                <div class="text-center">
                    <h3 class="text-primary fw-bold">Log in to <?php echo APP_NAME ?> Inventory Managament System
                    </h3>
                    <p>Log in with your <?php echo APP_NAME ?> account to get started or manage your
                        inventory</p>
                </div>
                <div class="card w-75 mx-auto mt-3 p-3">
                    <div class="row mb-4">
                        <div class="col-2 mx-auto">
                            <img src="<?php echo APP_LOGO ?>" alt="LOGO" class="img-fluid">
                        </div>
                    </div>

                    <?php if (isset($_GET['err']) && $_GET['err'] == 1): ?>
                        <div class="alert alert-danger py-2" role="alert">
                            Incorrect username or password
                        </div>
                    <?php endif; ?>

                    <form action="pages/requests/POST_credentials.php" method="POST">
                        <input type="text" class="form-control mb-3" name="form_email" placeholder="Username" />
                        <input type="password" class="form-control mb-3" name="form_password" placeholder="Password" />
                        <button type="submit" class="btn btn-primary w-100 fw-bold">Log In</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>

</html>