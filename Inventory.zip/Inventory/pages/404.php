<!--
    404.php
    This file displays a 404 error message for the StockSense Inventory Management System.
    It indicates that the requested page is not found or has been moved. 
    The user is encouraged to return to the dashboard.
    
    Features:
    1. Displays a 404 error image.
    2. Provides a message indicating the page is not found.
    3. Includes a link to redirect the user back to the dashboard.
    4. Includes a jQuery script to hide the loader when the document is ready.

-->

<div class="text-center mt-5 mt-lg-0">
    <img src="assets/images/404.webp" alt="404" class="img-fluid-w-50">


    <h1 class="fw-bold">OH NO!</h1>
    <h5>The page your looking for is not existing, or has been moved</h5>
    <h6>Please return to <a href="?p=dashboard">Dashboard</a></h6>
</div>
<script>
    $(document).ready(function () {
        $('#loader_container').fadeOut();
    });
</script>