<!--
    users.php
    This file contains the interface for managing users in the StockSense Inventory Management System.

    Features:
    1. Displays a table of existing users with details such as ID, name, username, role, status, date created, and last login.
    2. Provides options to add, edit, and delete users.
    3. Includes modals for adding, editing, and confirming deletion of users.
    4. Displays an alert message if a username already exists when adding a new user.
    
-->


<div class="container mt-5 mt-lg-0">
    <h2 class="fw-bold mb-3">Users Management</h2>
    <div class="d-flex align-items-center justify-content-between mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?p=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">User Management</li>
            </ol>
        </nav>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
            <i class="fa-solid fa-plus me-2"></i>
            Add User
        </button>
    </div>
    <?php if (isset($_GET['err']) && $_GET['err'] == 1): ?>
        <div class="alert alert-primary alert-dismissible fade show" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <strong>Username already exists, try different username</strong>
        </div>
    <?php endif; ?>

    <script>
        var alertList = document.querySelectorAll(".alert");
        alertList.forEach(function (alert) {
            new bootstrap.Alert(alert);
        });
    </script>




    <div class="card borders-0 p-3">
        <h6 class="fw-bold mb-3">
            <i class="fa-solid fa-users me-3"></i>
            User
        </h6>
        <div class="table-responsive">
            <table id="users_tbl" class="stripe cell-border display compact">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Date Created</th>
                        <th>Last Login</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>

    <div class="modal fade" id="addUserModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">
                        Add User
                    </h5>
                </div>
                <div class="modal-body">
                    <form action="pages/requests/POST_users.php" method="POST">
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form_label">First Name</label>
                                    <input type="text" name="form_fName" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form_label">Last Name</label>
                                    <input type="text" name="form_lName" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form_label">Username</label>
                            <input type="text" name="form_username" class="form-control" required>
                        </div>
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form_label">Password</label>
                                    <input type="password" name="form_password" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form_label">Role</label>
                                    <select name="form_role" class="form-select" required>
                                        <option value="" selected hidden>Select role</option>
                                        <option value="0">Admin</option>
                                        <option value="1">User</option>
                                        <option value="2">Employee</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <hr class="my-2">
                        <div class="row m-0 g-2">
                            <div class="col-12 col-lg-6">
                                <button type="submit" class="btn btn-success w-100">Add User</button>
                            </div>

                            <div class="col-12 col-lg-6">
                                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal"
                                    aria-label="Cancel">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class=" modal fade" id="editSuppliersModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">
                        Edit Product
                    </h5>
                </div>
                <div class="modal-body">
                    <form action="pages/requests/POST_users.php?action=update" method="POST">
                        <input type='hidden' name='form_data_id' />
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form_label">First Name</label>
                                    <input type="text" name="form_fName" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form_label">Last Name</label>
                                    <input type="text" name="form_lName" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form_label">Username</label>
                            <input type="text" name="form_username" class="form-control" required>
                        </div>
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form_label">Password</label>
                                    <input type="password" name="form_password" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form_label">Role</label>
                                    <select name="form_role" class="form-select" required>
                                        <option value="" selected hidden>Select role</option>
                                        <option value="0">Admin</option>
                                        <option value="1">User</option>
                                        <option value="2">Employee</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <hr class="my-2">
                        <div class="row m-0 g-2">
                            <div class="col-12 col-lg-6">
                                <button type="submit" class="btn btn-success w-100">Update User</button>
                            </div>
                            <div class="col-12 col-lg-6">
                                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal"
                                    aria-label="Cancel">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalTitle">
                        Delete supplier
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <span class="text-danger mb-3"><i class="fa-solid fa-triangle-exclamation fa-2xl"></i></span>
                    <p class="mb-0 text-danger">
                        You have selected to delete this supplier.
                    </p>
                    <br />
                    <p class="mb-0">
                        This will <strong>permanently</strong> delete the selected record
                        <strong>everywhere</strong>
                        they are used in the system.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" id="delete_yes_btn">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        No
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<script>

    let dataToFocus;

    const deleteRecord = data => {
        dataToFocus = data;
    }

    const editRecord = data => {
        dataToFocus = data;
        $.ajax({
            type: "GET",
            url: `pages/requests/GET_data_info.php?tbl=users&data=${dataToFocus}`,
            dataType: 'json',
            success: function (response) {
                const data = response.data;
                $('#editSuppliersModal input[name="form_data_id"]').val(data.user_id);
                $('#editSuppliersModal input[name="form_fName"]').val(data.first_name);
                $('#editSuppliersModal input[name="form_lName"]').val(data.last_name);
                $('#editSuppliersModal input[name="form_username"]').val(data.username);
                $('#editSuppliersModal input[name="form_password"]').val(data.password);
                $('#editSuppliersModal select[name="form_role"]').val(data.role);
            }
        });
    }

    $(document).ready(function () {

        $(document).ready(function () {
            $('#delete_yes_btn').click(function (e) {
                e.preventDefault();
                $.ajax({
                    url: 'pages/requests/POST_users.php',
                    method: 'POST',
                    data: { delete_id: dataToFocus },
                    success: function (response) {
                        location.reload();
                    },
                    error: function (xhr, status, error) {
                        // Handle error
                        console.error(xhr.responseText);
                    }
                });
            });
        });

    });
</script>
<script src="pages/requests/javascript/tbl_users.js"></script>