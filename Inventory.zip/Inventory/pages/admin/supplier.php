<!--
    supplier.php
    This file contains the interface for managing suppliers in the StockSense Inventory Management System.

    Features:
    1. Displays a table of existing suppliers with details such as ID, supplier name, coordinator name, address, phone number, and date created.
    2. Provides options to add, edit, and delete suppliers.
    3. Includes modals for adding, editing, and confirming deletion of suppliers.

-->

<div class="container mt-5 mt-lg-0">
    <h2 class="fw-bold">Suppliers</h2>

    <div class="d-flex align-items-center justify-content-between mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?p=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Suppliers</li>
            </ol>
        </nav>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSuppliersModal">
            <i class="fa-solid fa-plus me-2"></i>
            Add Supplier
        </button>
    </div>


    <div class="card borders-0 p-3">
        <h6 class="fw-bold mb-3">
            <i class="fa-solid fa-truck-field me-3"></i>
            Suppliers
        </h6>
        <div class="table-responsive">
            <table id="suppliers_tbl" class="stripe cell-border display compact">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Supplier</th>
                        <th>Coordinator</th>
                        <th>Address</th>
                        <th>Phone Number</th>
                        <th>Date Created</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Suppliers Modal -->
    <div class=" modal fade" id="addSuppliersModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">
                        Add Supplier
                    </h5>
                </div>
                <div class="modal-body">
                    <form action="pages/requests/POST_suppliers.php" method="POST">
                        <div class="mb-3">
                            <label for="" class="form-label">Supplier Name <span
                                    class="fst-italic">(company)</span></label>
                            <input type="text" class="form-control" name="form_supplier" required />
                        </div>
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Coordinator</label>
                                    <input type="text" class="form-control" name="form_coordinator" required />
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Phone Number</label>
                                    <input type="phone" class="form-control" name="form_phone" required />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label emp">Province</label>
                                    <select name="form_province" class="form-select" id="form_province" required>
                                        <option value="" selected hidden>Select Province</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label emp">Municipality / City</label>
                                    <select name="form_municipality" class="form-select" id="form_municipality"
                                        required>
                                        <option value="" selected hidden>Select Municipality</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label emp">Barangay</label>
                                    <select name="form_barangay" class="form-select" id="form_barangay" required>
                                        <option value="" selected hidden>Select Barangay</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label emp">Lot No. / Purok / Street</label>
                                    <input type="text" class="form-control" name="form_address"
                                        placeholder="123 Agriculture St.">
                                </div>
                            </div>
                        </div>
                        <hr class="my-2">
                        <div class="row m-0 g-2">
                            <div class="col-12 col-lg-6">
                                <button type="submit" class="btn btn-success w-100">Add supplier</button>
                            </div>

                            <div class="col-12 col-lg-6">
                                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal"
                                    aria-label="Cancel">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Supplier Modal -->
    <div class=" modal fade" id="editSuppliersModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">
                        Edit Supplier
                    </h5>
                </div>
                <div class="modal-body">
                    <form action="pages/requests/POST_suppliers.php?action=update" method="POST">
                        <input type='hidden' name='form_data_id' />
                        <div class="mb-3">
                            <label for="" class="form-label">Supplier Name <span
                                    class="fst-italic">(company)</span></label>
                            <input type="text" class="form-control" name="form_supplier" required />
                        </div>
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Coordinator</label>
                                    <input type="text" class="form-control" name="form_coordinator" required />
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Phone Number</label>
                                    <input type="phone" class="form-control" name="form_phone" required />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label emp">Province</label>
                                    <select name="form_province" class="form-select" id="edit_form_province" required>
                                        <option value="" selected hidden>Select an option</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label emp">Municipality / City</label>
                                    <select name="form_municipality" class="form-select" id="edit_form_municipality"
                                        required>
                                        <option value="" selected hidden>Select an option</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label emp">Barangay</label>
                                    <select name="form_barangay" class="form-select" id="edit_form_barangay" required>
                                        <option value="" selected hidden>Select an option</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label emp">Lot No. / Purok / Street</label>
                                    <input type="text" class="form-control" name="form_address"
                                        placeholder="123 Agriculture St.">
                                </div>
                            </div>
                        </div>
                        <hr class="my-2">
                        <div class="row m-0 g-2">
                            <div class="col-12 col-lg-6">
                                <button type="submit" class="btn btn-success w-100">Update supplier</button>
                            </div>

                            <div class="col-12 col-lg-6">
                                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal"
                                    aria-label="Cancel">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalTitle">
                        Delete supplier
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <span class="text-danger mb-3"><i class="fa-solid fa-triangle-exclamation fa-2xl"></i></span>
                    <p class="mb-0 text-danger">
                        You have selected to delete this supplier.
                    </p>
                    <br />
                    <p class="mb-0">
                        This will <strong>permanently</strong> delete the selected record <strong>everywhere</strong>
                        they are used in the system.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" id="delete_yes_btn">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        No
                    </button>
                </div>
            </div>
        </div>
    </div>

</div>
<script src="assets/vendor/phil.min.js"></script>
<script>
    let dataToFocus;

    function capitalize_first_letter(str) {
        const words = str.toLowerCase().split(' ');
        const capitalizedWords = words.map(word => word.charAt(0).toUpperCase() + word.slice(1));
        return capitalizedWords.join(' ');
    }

    const populateDropdown = (id, data, textCallback, valueCallback, selectedValue = null) => {
        $(`#${id}`).html('');
        $(`#${id}`).append($('<option>', {
            value: '',
            text: 'Select an option',
            selected: true,
            hidden: true
        }));
        data.forEach(element => {
            const text = textCallback(element);
            const value = valueCallback(element);
            const option = $('<option>', {
                value: value,
                text: text
            });
            if (value === selectedValue) {
                option.prop('selected', true);
            }
            $(`#${id}`).append(option);
        });
    }

    const deleteRecord = data => {
        dataToFocus = data;
    }

    const editRecord = data => {
        dataToFocus = data;
        $.ajax({
            type: "GET",
            url: `pages/requests/GET_data_info.php?tbl=supplier&data=${dataToFocus}`,
            dataType: 'json',
            success: function (response) {
                const data = response.data;
                $('#editSuppliersModal input[name="form_data_id"]').val(data.supplier_id);
                $('#editSuppliersModal input[name="form_supplier"]').val(data.supplier_name);
                $('#editSuppliersModal input[name="form_coordinator"]').val(data.coordinator_name);
                $('#editSuppliersModal input[name="form_address"]').val(data.address);
                $('#editSuppliersModal input[name="form_phone"]').val(data.phone);

                populateDropdown('edit_form_province', Philippines.sort(Philippines.provinces, "A"), element => capitalize_first_letter(element.name), element => element.prov_code, data.province_id);

                setTimeout(() => {
                    $('#edit_form_province').change();
                }, 10);

                setTimeout(() => {
                    $('#edit_form_municipality').change();
                }, 10);

                $('#edit_form_province').change(function (e) {
                    e.preventDefault();
                    const mun = Philippines.getCityMunByProvince($('#edit_form_province').val());
                    populateDropdown('edit_form_municipality', mun, element => capitalize_first_letter(element.name), element => element.mun_code, data.municipality_id);
                    $('#edit_form_municipality').change();
                });

                $('#edit_form_municipality').change(function (e) {
                    e.preventDefault();
                    const barangays = Philippines.getBarangayByMun(e.target.value);
                    populateDropdown('edit_form_barangay', barangays, element => capitalize_first_letter(element.name), element => element.name, data.barangay_id);
                });
            }
        });
    }

    $(document).ready(function () {
        // Province list append
        populateDropdown('form_province', Philippines.sort(Philippines.provinces, "A"), element => capitalize_first_letter(element.name), element => element.prov_code);

        // Populate municipality dropdown
        $('#form_province').change(function (e) {
            e.preventDefault();
            const mun = Philippines.getCityMunByProvince($('#form_province').val());
            populateDropdown('form_municipality', mun, element => capitalize_first_letter(element.name), element => element.mun_code);
            $('#form_municipality').change();
        });

        // Populate barangay dropdown
        $('#form_municipality').change(function (e) {
            e.preventDefault();
            const barangays = Philippines.getBarangayByMun(e.target.value);
            populateDropdown('form_barangay', barangays, element => capitalize_first_letter(element.name), element => element.name);
        });


        $('#delete_yes_btn').click(function (e) {
            e.preventDefault();
            $.ajax({
                url: 'pages/requests/POST_suppliers.php',
                method: 'POST',
                data: { delete_id: dataToFocus },
                success: function (response) {
                    location.reload();
                },
                error: function (xhr, status, error) {
                    // Handle error
                    console.error(xhr.responseText);
                }
            });
        });

        $('input[name="form_phone"]').on('input', function () {
            var phoneNumber = $(this).val();
            var formattedPhoneNumber = phoneNumber.replace(/\D/g, ''); // Remove non-digit characters

            // Limit to 11 digits
            if (formattedPhoneNumber.length > 11) {
                formattedPhoneNumber = formattedPhoneNumber.slice(0, 11);
            }

            // Update the input value
            $(this).val(formattedPhoneNumber);
        });

    });
</script>
<script src="pages/requests/javascript/tbl_supplier.js"></script>