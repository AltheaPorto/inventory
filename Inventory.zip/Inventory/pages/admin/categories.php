<!--
    categories.php
    This file displays the categories page for administrators or employees in the StockSense Inventory Management System.
    It allows them to manage categories, including adding, editing, and deleting categories.

    Features:
    1. Displays a list of categories in a table format with options to edit or delete each category.
    2. Provides a modal for adding new categories.
    3. Provides a modal for editing existing categories.
    4. Displays a confirmation modal for deleting categories.
    
-->


<div class="container mt-5 mt-lg-0">
    <h2 class="fw-bold">Categories</h2>

    <div class="d-flex align-items-center justify-content-between mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?p=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Categories</li>
            </ol>
        </nav>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoriesModal">
            <i class="fa-solid fa-plus me-2"></i>
            Add Category
        </button>
    </div>


    <div class="card borders-0 p-3">
        <h6 class="fw-bold">
            <i class="fa-solid fa-puzzle-piece me-3"></i>
            Categories
        </h6>
        <div class="table-responsive">
            <table id="suppliers_tbl" class="stripe cell-border display compact">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Category Name</th>
                        <th>Status</th>
                        <th>Date Created</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>

    <div class="modal fade" id="addCategoriesModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">
                        Add Category
                    </h5>
                </div>
                <div class="modal-body">
                    <form action="pages/requests/POST_categories.php" method="POST">
                        <div class="mb-3">
                            <label for="" class="form-label">Category Name</label>
                            <input type="text" class="form-control" name="form_category" required />
                        </div>
                        <hr class="my-2">
                        <div class="row m-0 g-2">
                            <div class="col-12 col-lg-6">
                                <button type="submit" class="btn btn-success w-100">Add Category</button>
                            </div>

                            <div class="col-12 col-lg-6">
                                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal"
                                    aria-label="Cancel">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class=" modal fade" id="editSuppliersModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">
                        Edit Category
                    </h5>
                </div>
                <div class="modal-body">
                    <form action="pages/requests/POST_categories.php?action=update" method="POST">
                        <input type='hidden' name='form_data_id' />
                        <div class="mb-3">
                            <label for="" class="form-label">Category Name</label>
                            <input type="text" class="form-control" name="form_category" required />
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Status</label>
                            <select class="form-select" name="form_status">
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="row m-0 g-2">
                            <div class="col-12 col-lg-6">
                                <button type="submit" class="btn btn-success w-100">Update Category</button>
                            </div>

                            <div class="col-12 col-lg-6">
                                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal"
                                    aria-label="Cancel">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalTitle">
                        Delete supplier
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <span class="text-danger mb-3"><i class="fa-solid fa-triangle-exclamation fa-2xl"></i></span>
                    <p class="mb-0 text-danger">
                        You have selected to delete this category.
                    </p>
                    <br />
                    <p class="mb-0">
                        This will <strong>permanently</strong> delete the selected record
                        <strong>everywhere</strong>
                        they are used in the system.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" id="delete_yes_btn">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        No
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    let dataToFocus;
    const editRecord = data => {
        dataToFocus = data;
        $.ajax({
            type: "GET",
            url: `pages/requests/GET_data_info.php?tbl=categories&data=${dataToFocus}`,
            dataType: 'json',
            success: function (response) {
                const data = response.data;
                $('#editSuppliersModal input[name="form_data_id"]').val(data.category_id);
                $('#editSuppliersModal input[name="form_category"]').val(data.category_name);
                $('#editSuppliersModal select[name="form_status"]').val(data.status);
            }
        });
    }


    const deleteRecord = data => {
        dataToFocus = data;
    }

    $(document).ready(function () {
        $('#delete_yes_btn').click(function (e) {
            e.preventDefault();
            $.ajax({
                url: 'pages/requests/POST_categories.php',
                method: 'POST',
                data: { delete_id: dataToFocus },
                success: function (response) {
                    location.reload();
                },
                error: function (xhr, status, error) {
                    // Handle error
                    console.error(xhr.responseText);
                }
            });
        });
    });

</script>
<script src="pages/requests/javascript/tbl_categories.js"></script>