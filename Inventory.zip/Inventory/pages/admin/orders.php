<!--
    orders.php
    This file displays the orders management interface for viewing and managing orders in the StockSense Inventory Management System.

    Features:
    1. Displays a table of existing orders with details such as product name, quantity, total price, category, supplier, buyer, and date ordered.
    2. Provides a modal for previewing product images.

-->

<div class="container mt-5 mt-lg-0">
    <h2 class="fw-bold">Orders</h2>

    <div class="d-flex align-items-center justify-content-between mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?p=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Orders</li>
            </ol>
        </nav>
    </div>


    <div class="card borders-0 p-3">
        <h6 class="fw-bold">
            <i class="fa-solid fa-cart-shopping me-3"></i>
            Orders
        </h6>
        <div class="table-responsive">
            <table id="inventory_tbl" class="stripe cell-border display compact">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Image</th>
                        <th>Product Name</th>
                        <th>Selling Price</th>
                        <th>Quantity</th>
                        <th>Total Price</th>
                        <th>Category</th>
                        <th>Supplier</th>
                        <th>Buyer</th>
                        <th>Date Ordered</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>

    <div class="modal fade" id="addStocks" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">
                        Add Stock Inventory
                    </h5>
                </div>
                <div class="modal-body">
                    <form action="pages/requests/POST_stock.php" method="POST">
                        <div class="mb-3">
                            <label for="" class="form-label">Product Name</label>
                            <select class="form-select" name="form_product" required>
                                <option value="" selected hidden>Select Product</option>
                            </select>
                        </div>
                        <div class="row gx-4">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Quantity</label>
                                    <input type="number" min=0 class="form-control" name="form_quantity" required />
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Unit</label>
                                    <select class="form-select" name="form_unit" required>
                                        <option value="" selected hidden>Select Unit</option>
                                        <option value="Bags">Bags</option>
                                        <option value="Bottles">Bottles</option>
                                        <option value="Box">Box</option>
                                        <option value="Dozens">Dozens</option>
                                        <option value="Feet">Feet</option>
                                        <option value="Gallon">Gallon</option>
                                        <option value="Grams">Grams</option>
                                        <option value="Inch">Inch</option>
                                        <option value="Kg">Kg</option>
                                        <option value="Liters">Liters</option>
                                        <option value="Meter">Meter</option>
                                        <option value="Nos">Nos</option>
                                        <option value="Packet">Packet</option>
                                        <option value="Rolls">Rolls</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <hr class="my-2">
                        <div class="row m-0 g-2">
                            <div class="col-12 col-lg-6">
                                <button type="submit" class="btn btn-success w-100">Add Stock</button>
                            </div>

                            <div class="col-12 col-lg-6">
                                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal"
                                    aria-label="Cancel">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal_image_preview" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <p class="m-0">Product preview</p>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>


</div>
<script>

    const preview = image => {
        $('#modal_image_preview .modal-body').empty();
        $('#modal_image_preview .modal-body').append(`<img src=${image.src} class="img-fluid"/>`);
    }


</script>
<script src="pages/requests/javascript/tbl_orders.js"></script>