<!--
    dashboard.php
    This file displays the dashboard for administrators or employees in the StockSense Inventory Management System.
    It provides an overview of various statistics and recent activities.

    Features:
    1. Displays a welcome message with the system name.
    2. Shows counters for users, categories, products, and orders.
    3. Displays a table of recently added products.
    4. Shows a table of latest sales.
    5. If the user role is admin, also displays a table of newly created users.

-->



<div class="container mt-5 mt-lg-0">
    <h2 class="fw-bold mb-3">Dashboard</h2>

    <div class="alert alert-primary alert-dismissible fade show" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <p class="m-0">Welcome to <span class="fw-bold"><?php echo APP_NAME ?> Inventory Management System</span></p>
    </div>
    <div class="row m-0 gy-2 mb-5">
        <?php if ($role === 0): ?>
            <div class="col-12 col-sm-6 col-lg-3 ">
                <div class="row m-0">
                    <div class="col-4 bg-success d-flex justify-content-center align-items-center">
                        <h1 class="m-0 text-white"><i class="fa-solid fa-user"></i></h1>
                    </div>
                    <div class="col-8 bg-white border border-1 p-3 py-4 text-center">
                        <h2 class="m-0" id="db_user_count"></h2>
                        <span class="text-muted">Users</span>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="row m-0">
                <div class="col-4 bg-danger d-flex justify-content-center align-items-center">
                    <h1 class="m-0 text-white"><i class="fa-solid fa-puzzle-piece"></i></h1>
                </div>
                <div class="col-8 bg-white border border-1 p-3 py-4 text-center">
                    <h2 class="m-0" id="db_category_count"></h2>
                    <span class="text-muted">Categories</span>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="row m-0">
                <div class="col-4 bg-primary d-flex justify-content-center align-items-center">
                    <h1 class="m-0 text-white"><i class="fa-solid fa-box"></i></h1>
                </div>
                <div class="col-8 bg-white border border-1 p-3 py-4 text-center">
                    <h2 class="m-0" id="db_product_count"></h2>
                    <span class="text-muted">Products</span>
                </div>
            </div>
        </div>
        <div class="col-12 col-sm-6 col-lg-3">
            <div class="row m-0">
                <div class="col-4 bg-warning d-flex justify-content-center align-items-center">
                    <h1 class="m-0 text-white"><i class="fa-solid fa-peso-sign"></i></h1>
                </div>
                <div class="col-8 bg-white border border-1 p-3 py-4 text-center">
                    <h2 class="m-0" id="db_orders_count">0</h2>
                    <span class="text-muted">Orders</span>
                </div>
            </div>
        </div>
    </div>
    <div class="row gx-4 gy-2">
        <div class="col-12 col-lg-4 d-flex flex-column">
            <div class="p-3 py-2 fw-bold border-bottom border-primary border-4"
                style="background-color: var(--bs-gray-200)">
                <div class="d-flex align-items-center ">
                    <i class="fa-solid fa-table-cells me-3"></i>
                    <span>RECENTLY ADDED PRODUCT</span>
                </div>
            </div>
            <div class="bg-white p-3">
                <table class="table table-striped table-sm table-bordered m-0" id="db_recent_product">
                    <thead class="table-primary">
                        <tr>
                            <th>Product</th>
                            <th>Selling Price</th>
                            <th>Stock</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>

        </div>
        <div class="col-12 col-lg-4 d-flex flex-column">
            <div class="p-3 py-2 fw-bold border-bottom border-primary border-4"
                style="background-color: var(--bs-gray-200)">
                <div class="d-flex align-items-center ">
                    <i class="fa-solid fa-table-cells me-3"></i>
                    <span>LATEST SALES</span>
                </div>
            </div>
            <div class="bg-white p-3">
                <table class="table table-striped table-sm table-bordered m-0" id="db_recent_sales">
                    <tbody>
                    </tbody>
                </table>
            </div>

        </div>
        <?php if ($role === 0): ?>
            <div class="col-12 col-lg-4 d-flex flex-column">
                <div class="p-3 py-2 fw-bold border-bottom border-primary border-4"
                    style="background-color: var(--bs-gray-200)">
                    <div class="d-flex align-items-center ">
                        <i class="fa-solid fa-table-cells me-3"></i>
                        <span>NEWLY CREATED USERS</span>
                    </div>
                </div>
                <div class="bg-white p-3">
                    <table class="table table-striped table-sm table-bordered m-0" id="db_recent_users">
                        <thead class="table-primary">
                            <tr>
                                <th>Username</th>
                                <th>Name</th>
                                <th>Role</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>



</div>
<script>
    $(document).ready(function () {
        $.ajax({
            method: "GET",
            url: "pages/requests/GET_dashboard.php?data=counter",
            dataType: "json",
            success: function (response) {
                $('#db_user_count').html(response.user_count)
                $('#db_category_count').html(response.category_count)
                $('#db_product_count').html(response.product_count)
                $('#db_orders_count').html(response.order_count)
                $('#loader_container').fadeOut();
            }
        });

        $.ajax({
            method: "GET",
            url: "pages/requests/GET_dashboard.php?data=products",
            dataType: "json",
            success: function (response) {
                $('#db_recent_product tbody').empty();
                if (response.length != 0) {
                    $.each(response, function (index, product) {
                        // Create a new row
                        var row = $('<tr>');

                        // Append cells with product data
                        row.append($('<td>').text(product.product_name));
                        row.append($('<td>').text(product.selling_price));
                        row.append($('<td>').text(product.stock_value))

                        // Append the row to the table body
                        $('#db_recent_product tbody').append(row);
                    });
                }
                else {
                    var row = $('<tr>');
                    row.append($('<td colspan="3" class="text-center">').text("NO RECORDS AVAILABLE"));
                    $('#db_recent_product tbody').append(row);
                }
            }
        });

        $.ajax({
            method: "GET",
            url: "pages/requests/GET_dashboard.php?data=user",
            dataType: "json",
            success: function (response) {
                $('#db_recent_users tbody').empty();
                if (response.length != 0) {
                    $.each(response, function (index, user) {
                        // Create a new row
                        var row = $('<tr>');

                        // Append cells with product data
                        row.append($('<td>').text(user.username));
                        row.append($('<td>').text(user.name));
                        row.append($('<td>').text(user.role));

                        // Append the row to the table body
                        $('#db_recent_users tbody').append(row);
                    });
                }
                else {
                    var row = $('<tr>');
                    row.append($('<td colspan="3" class="text-center">').text("NO RECORDS AVAILABLE"));
                    $('#db_recent_users tbody').append(row);
                }

            }
        });

        $.ajax({
            method: "GET",
            url: "pages/requests/GET_dashboard.php?data=orders",
            dataType: "json",
            success: function (response) {
                $('#db_recent_sales tbody').empty();
                if (response.length != 0) {
                    $.each(response, function (index, order) {
                        // Create a new row
                        var row = $('<tr>');
                        // Append cells with order data
                        row.append($('<td>').html(`<strong>${order.name}</strong> ordered <strong>${order.quantity}</strong> unit(s) of <strong>${order.product_name}</strong> on <strong>${order.order_date}</strong>`));

                        // Append the row to the table body
                        $('#db_recent_sales tbody').append(row);
                    });
                }
                else {
                    var row = $('<tr>');
                    row.append($('<td colspan="3" class="text-center">').text("NO RECENT SALES"));
                    $('#db_recent_sales tbody').append(row);
                }
            }
        });

    });
</script>