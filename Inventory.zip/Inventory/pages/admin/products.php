<!--
    products.php
    This file contains the interface for managing products in the StockSense Inventory Management System.

    Features:
    1. Displays a table of existing products with details such as ID, image, product name, category, supplier, buying price, selling price, status, and creation date.
    2. Provides options to add, edit, and delete products.
    3. Includes modals for adding, editing, and confirming deletion of products.

-->

<div class="container mt-5 mt-lg-0">
    <h2 class="fw-bold">Products</h2>

    <div class="d-flex align-items-center justify-content-between mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?p=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Products</li>
            </ol>
        </nav>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductsModal">
            <i class="fa-solid fa-plus me-2"></i>
            Add Product
        </button>
    </div>


    <div class="card borders-0 p-3">
        <h6 class="fw-bold">
            <i class="fa-solid fa-box me-3"></i>
            Products
        </h6>
        <div class="table-responsive">
            <table id="suppliers_tbl" class="stripe cell-border display compact">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Image</th>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Supplier</th>
                        <th>Buying Price</th>
                        <th>Selling Price</th>
                        <th>Status</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>


    <div class="modal fade" id="addProductsModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">
                        Add Product
                    </h5>
                </div>
                <div class="modal-body">
                    <form action="pages/requests/POST_products.php" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="" class="form-label">Choose file</label>
                            <input type="file" class="form-control" name="form_image" accept="image/png, image/jpeg"
                                aria-describedby=" fileHelpId" required />
                            <div id="fileHelpId" class="form-text">Image cannot be edited after uploaded.</div>
                        </div>

                        <div class="mb-3">
                            <label for="" class="form-label">Product Name</label>
                            <input type="text" class="form-control" name="form_product" required />
                        </div>
                        <div class="row gx-4">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Buying Price</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">₱</span>
                                        </div>
                                        <input type="text" class="form-control" name="form_buying_price">
                                        <div class="input-group-append">
                                            <span class="input-group-text">.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Selling Price</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">₱</span>
                                        </div>
                                        <input type="text" class="form-control" name="form_selling_price">
                                        <div class="input-group-append">
                                            <span class="input-group-text">.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Category</label>
                            <select type="text" class="form-select" name="form_category" required>
                                <option value="" selected hidden>Select category</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Supplier</label>
                            <select type="text" class="form-select" name="form_supplier" required>
                                <option value="" hidden selected>Select supplier</option>
                            </select>
                        </div>

                        <hr class="my-2">
                        <div class="row m-0 g-2">
                            <div class="col-12 col-lg-6">
                                <button type="submit" class="btn btn-success w-100">Add Product</button>
                            </div>

                            <div class="col-12 col-lg-6">
                                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal"
                                    aria-label="Cancel">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class=" modal fade" id="editSuppliersModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">
                        Edit Product
                    </h5>
                </div>
                <div class="modal-body">
                    <form action="pages/requests/POST_products.php?action=update" method="POST">
                        <input type='hidden' name='form_data_id' />
                        <div class="mb-3">
                            <label for="" class="form-label">Product Name</label>
                            <input type="text" class="form-control" name="form_product" required />
                        </div>
                        <div class="row gx-4">
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Buying Price</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">₱</span>
                                        </div>
                                        <input type="text" class="form-control" name="form_buying_price">
                                        <div class="input-group-append">
                                            <span class="input-group-text">.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="mb-3">
                                    <label for="" class="form-label">Selling Price</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">₱</span>
                                        </div>
                                        <input type="text" class="form-control" name="form_selling_price">
                                        <div class="input-group-append">
                                            <span class="input-group-text">.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Category</label>
                            <select type="text" class="form-select" name="form_category" required></select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Supplier</label>
                            <select type="text" class="form-select" name="form_supplier" required></select>
                        </div>

                        <hr class="my-2">
                        <div class="row m-0 g-2">
                            <div class="col-12 col-lg-6">
                                <button type="submit" class="btn btn-success w-100">Update product</button>
                            </div>

                            <div class="col-12 col-lg-6">
                                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal"
                                    aria-label="Cancel">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalTitle">
                        Delete supplier
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <span class="text-danger mb-3"><i class="fa-solid fa-triangle-exclamation fa-2xl"></i></span>
                    <p class="mb-0 text-danger">
                        You have selected to delete this product.
                    </p>
                    <br />
                    <p class="mb-0">
                        This will <strong>permanently</strong> delete the selected record <strong>everywhere</strong>
                        they are used in the system.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" id="delete_yes_btn">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        No
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal_image_preview" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <p class="m-0">Product preview</p>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>

</div>
<script>
    let dataToFocus;
    let supplier_list;
    let category_list;

    const deleteRecord = data => {
        dataToFocus = data;
    }

    const editRecord = data => {
        dataToFocus = data;
        $.ajax({
            type: "GET",
            url: `pages/requests/GET_data_info.php?tbl=products&data=${dataToFocus}`,
            dataType: 'json',
            success: function (response) {
                const data = response.data;
                $('#editSuppliersModal input[name="form_data_id"]').val(data.product_id);
                $('#editSuppliersModal input[name="form_product"]').val(data.product_name);
                $('#editSuppliersModal input[name="form_quantity"]').val(data.quantity);
                $('#editSuppliersModal select[name="form_unit"]').val(data.unit);
                $('#editSuppliersModal input[name="form_buying_price"]').val(data.buying_price);
                $('#editSuppliersModal input[name="form_selling_price"]').val(data.selling_price);
                $('#editSuppliersModal select[name="form_category"').val(data.category_id);
                $('#editSuppliersModal select[name="form_supplier"]').val(data.supplier_id);
            }
        });
    }

    const preview = image => {
        $('#modal_image_preview .modal-body').empty();
        $('#modal_image_preview .modal-body').append(`<img src=${image.src} class="img-fluid"/>`);
    }

    $(document).ready(function () {
        $('input[name="form_buying_price"], input[name="form_selling_price"]').on('keydown', function (event) {
            // Get the value entered by the user
            var value = $(this).val();

            // Check if the entered key is a digit, backspace, or delete
            if ((event.keyCode >= 48 && event.keyCode <= 57) || // Digits
                (event.keyCode >= 96 && event.keyCode <= 105) || // Numpad digits
                event.keyCode == 8 || // Backspace
                event.keyCode == 46 || // Delete
                event.keyCode == 37 || // Left arrow
                event.keyCode == 39 || // Right arrow
                event.keyCode == 9) { // Tab
                return true; // Allow the key
            } else if (event.keyCode == 189 || event.keyCode == 109) { // Minus sign
                // Prevent typing minus sign for negative numbers
                event.preventDefault();
            } else {
                event.preventDefault(); // Prevent typing other characters
            }
        });

        $('input[name="form_image"]').change(function () {
            var fileSize = this.files[0].size;
            var maxSize = 5000000; // Maximum file size in bytes (e.g. 500000 bytes = 500 KB)

            if (fileSize > maxSize) {
                alert('File size exceeds the maximum limit (5 MB). Please upload a smaller file.');
                $(this).val(''); // Clear the file input to prevent uploading the file
            }
        });

        $.ajax({
            method: "GET",
            url: "pages/requests/GET_data.php?data=supplier",
            dataType: "json",
            success: function (response) {
                response.data.sort(function (a, b) {
                    var nameA = a.supplier_name.toLowerCase();
                    var nameB = b.supplier_name.toLowerCase();
                    if (nameA < nameB) {
                        return -1;
                    }
                    if (nameA > nameB) {
                        return 1;
                    }
                    return 0;
                });
                supplier_list = response.data;
                $.each(response.data, function (indexInArray, valueOfElement) {
                    $('#addProductsModal select[name="form_supplier"').append($('<option>', {
                        value: valueOfElement.supplier_id,
                        text: `${valueOfElement.supplier_name} (${valueOfElement.coordinator_name})`
                    }));

                    $('#editSuppliersModal select[name="form_supplier"').append($('<option>', {
                        value: valueOfElement.supplier_id,
                        text: `${valueOfElement.supplier_name} (${valueOfElement.coordinator_name})`
                    }));
                });
            }
        });

        $.ajax({
            method: "GET",
            url: "pages/requests/GET_data.php?data=categories",
            dataType: "json",
            success: function (response) {
                response.data.sort(function (a, b) {
                    var nameA = a.category_name.toLowerCase();
                    var nameB = b.category_name.toLowerCase();
                    if (nameA < nameB) {
                        return -1;
                    }
                    if (nameA > nameB) {
                        return 1;
                    }
                    return 0;
                });
                category_list = response.data;
                $.each(response.data, function (indexInArray, valueOfElement) {
                    if (valueOfElement.status === 'Active') {
                        $('#addProductsModal select[name="form_category"').append($('<option>', {
                            value: valueOfElement.category_id,
                            text: `${valueOfElement.category_name}`
                        }));

                        $('#editSuppliersModal select[name="form_category"').append($('<option>', {
                            value: valueOfElement.category_id,
                            text: `${valueOfElement.category_name}`
                        }));
                    }
                });
            }
        });

        $('#delete_yes_btn').click(function (e) {
            e.preventDefault();
            $.ajax({
                url: 'pages/requests/POST_products.php',
                method: 'POST',
                data: { delete_id: dataToFocus },
                success: function (response) {
                    location.reload();
                },
                error: function (xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>
<script src="pages/requests/javascript/tbl_products.js"></script>