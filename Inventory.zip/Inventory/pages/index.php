<?php
/**
 * index.php
 * 
 * This file serves as the main entry point for the authenticated section of the StockSense Inventory Management System. 
 * It includes the following features:
 * 
 * 1. Checks the user's role from the session to determine access permissions and default page.
 * 2. Redirects employees away from unauthorized pages.
 * 3. Dynamically sets the page to be included based on URL parameters, with fallbacks for unauthorized access and page not found.
 * 
 */

$role = isset($_SESSION['role']) ? $_SESSION['role'] : null;
$page = 'dashboard';


if ($role === 2 && isset($_GET['p']) && $_GET['p'] === 'users') {
    // Redirect to the default page
    header("Location: ?p=" . $page);
    exit();
}
// If the page parameter is provided in the URL, use it (unless it's "users" for employees)
if (isset($_GET['p']) && !empty($_GET['p']) && !($role === 2 && $_GET['p'] === 'users')) {
    $page = $_GET['p'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo APP_NAME ?></title>

    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo FAVICON_32 ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo FAVICON_16 ?>">

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap 5 -->
    <link href="assets/vendor/BS5/css/bootstrap.min.css" rel="stylesheet">
    <script src="assets/vendor/BS5/js/bootstrap.bundle.min.js"></script>

    <!-- FontAwesome 6.4.0 CSS -->
    <link rel="stylesheet" href="assets/vendor/FontAwesome6/all.min.css">

    <!-- JQuery Library -->
    <script src="assets/vendor/jQuery/jquery-3.7.0.min.js"></script>

    <!-- Custom JavaScript -->
    <script src="assets/scripts.js"></script>

    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/styles.css">

    <!-- Chart JS -->
    <script src="assets/vendor/chartJS/chart.js"></script>

    <!-- DataTables -->
    <link href="assets/vendor/DataTables/datatables.min.css" rel="stylesheet">
    <script src="assets/vendor/DataTables/datatables.min.js"></script>

</head>

<body data-sidebar="close">
    <div id="sidebar" class="d-flex flex-column">
        <div class="trigger_mobile d-lg-none">
            <i class="fa-solid fa-xmark"></i>
        </div>
        <div class="text-center px-3 py-4">
            <div class="row">
                <div class="col-2 col-lg-4 mx-auto">
                    <img src="<?php echo APP_LOGO ?>" alt="logo" class="img-fluid">
                </div>
            </div>
            <h3 class="m-0 text-white fw-bold"><?php echo APP_NAME ?></h3>
        </div>
        <div class="d-flex flex-column justify-content-between h-100">
            <ul class="list-unstyled">
                <li class="nav-item <?php echo $page === 'dashboard' ? 'active' : ''; ?>">
                    <a class="nav-link" href="?p=dashboard" aria-current="page">
                        <i class="fa-solid fa-gauge"></i>
                        Dashboard
                    </a>
                </li>
                <?php if ($role == 0 || $role == 2): ?>
                    <li class="nav-item <?php echo $page === 'products' ? 'active' : ''; ?>">
                        <a class="nav-link" href="?p=products" aria-current="page">
                            <i class="fa-solid fa-bell"></i>
                            Products
                        </a>
                    </li>
                    <li class="nav-item <?php echo $page === 'inventory' ? 'active' : ''; ?>">
                        <a class="nav-link" href="?p=inventory" aria-current="page">
                            <i class="fa-solid fa-list-check"></i>
                            Inventory
                        </a>
                    </li>
                <?php endif; ?>
                <li class="nav-item <?php echo $page === 'orders' ? 'active' : ''; ?>">
                    <a class="nav-link" href="?p=orders" aria-current="page">
                        <i class="fa-solid fa-cart-shopping"></i>
                        Orders
                    </a>
                </li>
                <?php if ($role == 0 || $role == 2): ?>
                    <li class="nav-item <?php echo $page === 'categories' ? 'active' : ''; ?>">
                        <a class="nav-link" href="?p=categories" aria-current="page">
                            <i class="fa-solid fa-puzzle-piece"></i>
                            Categories
                        </a>
                    </li>
                    <li class="nav-item <?php echo $page === 'supplier' ? 'active' : ''; ?>">
                        <a class="nav-link" href="?p=supplier" aria-current="page">
                            <i class="fa-solid fa-truck-field"></i>
                            Suppliers
                        </a>
                    </li>
                <?php endif; ?>
                <?php if ($role == 0): ?>
                    <li class="nav-item <?php echo $page === 'users' ? 'active' : ''; ?>">
                        <a class="nav-link" href="?p=users" aria-current="page">
                            <i class="fa-solid fa-users"></i>
                            User Management
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="bg-primary d-flex gap-3 align-items-center justify-content-between px-3 py-4 text-white">
                <i class="fa-solid fa-circle-user fa-xl"></i>
                <p class="m-0" id="account"><?php echo $_SESSION['username'] ?></p>
                <a id="log-out-btn" class="btn text-white btn-sm" href="pages/requests/logout.php" role="button">
                    <i class="fa-solid fa-right-from-bracket fa-lg"></i>
                </a>

            </div>
        </div>
    </div>
    <div id="main">
        <div id="loader_container">
            <div id="loader"></div>
            <h5 class="fw-bold">LOADING DATA...</h5>
        </div>
        <div id="trigger_sidebar" title="Open Sidebar">
            <div id="trigger" class="d-flex flex-column align-items-center" data-state="close">
                <div class="trigger_rounded"></div>
                <div class="trigger_rounded"></div>
            </div>
        </div>
        <header class="d-lg-none bg-dark p-2 py-3" style="z-index: 98;">
            <div class=" row m-0">
                <div class="col-4">
                    <div class="trigger_mobile">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                </div>
                <div class="col-8 d-flex align-items-center gap-3">
                    <img src="<?php echo APP_LOGO ?>" alt="LOGO" class="col-1">
                    <p class="m-0 text-white fw-bold"><?php echo APP_NAME ?></p>
                </div>
            </div>
        </header>
        <div class="px-lg-5 px-3 py-3 pt-lg-3 pt-5">
            <?php
            if ($role == 1) {
                $user_page = ['dashboard', 'orders'];
                if (in_array($page, $user_page)) {
                    // Include the requested page
                    include_once ('user/' . $page . '.php');
                } else {
                    // Page not found, include 404 page
                    include_once ('404.php');
                }
            } else {
                $admin_page = ['dashboard', 'products', 'orders', 'inventory', 'categories', 'supplier', 'users', 'notifications']; // Add more pages 
                // Check if the requested page is valid
                if (in_array($page, $admin_page)) {
                    // Include the requested page
                    include_once ('admin/' . $page . '.php');
                } else {
                    // Page not found, include 404 page
                    include_once ('404.php');
                }
            }
            ?>
        </div>
    </div>
    <script>
        const ROLE_PLACEHOLDER = <?php echo $role; ?>
    </script>

</body>

</html>