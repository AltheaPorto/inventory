<!--
    dashboard.php
    This file displays the dashboard page for users in the StockSense Inventory Management System.
    It shows all available items in the system and provides functionality for searching, sorting, and viewing product details.

    Features:
    1. Displays a search bar for searching products by name.
    2. Allows users to sort products by different criteria such as oldest, latest, price low to high, price high to low, and category.
    3. Displays products in cards format with details such as name, category, price, and stock availability.
    4. Includes a modal for viewing detailed product information including image, name, supplier, category, price, stock, and quantity.
    5. Provides functionality to order products directly from the dashboard.

-->



<?php
require_once ('required/db_conn.php');
require_once ('pages/requests/GET_user_dashboard.php');
?>


<div class="container mt-5 mt-lg-0">
    <h2 class="fw-bold mb-5">Dashboard</h2>
    <div class="row m-0">
        <div class="col-12 col-lg-7 mx-auto">
            <form method="GET" id="searchForm" class="mb-3">
                <div class="input-group">
                    <input type="text" class="form-control border-end-0" placeholder="Search for product" name="search">
                    <div class="input-group-text bg-white border-start-0">
                        <button type="submit" class="btn btn-primary">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </button>
                    </div>
                </div>
            </form>
            <div class="navbar navbar-expand-lg navbar-light bg-light px-3">
                <span class="me-3 fw-bold">Sort by</span>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#sorter_nav"
                    aria-controls="sorter_nav" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa-solid fa-filter"></i>
                </button>
                <div class="collapse navbar-collapse" id="sorter_nav">
                    <ul class="navbar-nav ml-auto gap-2">
                        <li class="d-flex align-items-center">
                            <button type="button"
                                class="btn btn-sm <?php echo ($sortOption === 'oldest') ? 'selected' : ''; ?>"
                                data-sort="oldest">Oldest</button>
                        </li>
                        <li class="d-flex align-items-center">
                            <button type="button"
                                class="btn btn-sm <?php echo ($sortOption === 'latest') ? 'selected' : ''; ?>"
                                data-sort="latest">Latest</button>
                        </li>
                        <li class="d-flex align-items-center">
                            <button type="button"
                                class="btn btn-sm <?php echo ($sortOption === 'low-high') ? 'selected' : ''; ?>"
                                data-sort="low-high">Price: Low to High</button>
                        </li>
                        <li class="d-flex align-items-center">
                            <button type="button"
                                class="btn btn-sm <?php echo ($sortOption === 'high-low') ? 'selected' : ''; ?>"
                                data-sort="high-low">Price: High to Low</button>
                        </li>
                        <li class="d-flex align-items-center">
                            <select class="form-select form-select-sm" id="form-sort-category" data-sort="category">
                                <option value="" hidden>Select Category</option>
                                <option value="0">None</option>
                            </select>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="row m-0 mt-3 g-2" id="product_wrapper">
                <?php
                if ($result->num_rows > 0) {
                    $products = $result->fetch_all(MYSQLI_ASSOC);
                    foreach ($products as $product): ?>
                        <div class="col-6 col-lg-4 product_card" title="<?php echo $product['product_name']; ?>">
                            <?php if ($product['stock_value'] > 0): ?>
                                <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#viewProduct"
                                    onclick="viewProduct(<?php echo $product['product_id'] ?>)">
                                <?php endif; ?>
                                <div class="card h-100">
                                    <?php if ($product['stock_value'] == 0): ?>
                                        <div class="na_stamp"></div>
                                    <?php endif; ?>
                                    <img src="<?php echo $product['image']; ?>" class="card-img-top" alt="Product">
                                    <div class="card-body">
                                        <h6 class="card-title fw-bold m-0">
                                            <?php echo $product['product_name']; ?>
                                        </h6>
                                        <span class="text-muted small">
                                            <?php echo $product['category_name']; ?>
                                        </span>
                                        <h6 class="selling-price mt-2 mb-0">
                                            ₱<?php echo $product['price']; ?>
                                        </h6>
                                        <?php if (($product['stock_value'] != 0) && ($product['stock_value'] <= ($product['initial_stock'] * 0.1))): ?>
                                            <span class="text-warning small fw-bold">Low Stock</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php if ($product['stock_value'] > 0): ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach;
                } else {
                    if (!empty($searchTerm)) {
                        echo
                            '<div class="alert alert-primary" role="alert">
                                <p class="m-0">No products found for "<strong>' . $searchTerm . '</strong>"</p>
                            </div>';
                    } else {
                        echo '<h3 class="text-center">NO PRODUCTS IN STOCK AT THE MOMENT</h3>';
                    }
                } ?>
            </div>
        </div>
    </div>


    <div class="modal fade" id="viewProduct" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">View Product Info</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="pages/requests/POST_order.php" method="POST">
                        <div class="my-4">
                            <input type="hidden" name="form_data_id" />
                            <div class="row m-0">
                                <div class="col-12 col-lg-6">
                                    <img src="" class="img-fluid border border-1 rounded-3 p-3" id="product_img"
                                        alt="product">
                                </div>
                                <div class="col-12 col-lg-6">
                                    <h4 class="fw-bold m-0" id="product_name"></h4>
                                    <span class="text-muted fst-italic" id="product_supplier"></span><br>
                                    <span id="product_category"></span>
                                    <h2 id="product_price" class="my-3 fw-bold text-primary"></h2>
                                    <div class="row align-items-center mb-3">
                                        <div class="col-6">
                                            <div class="input-group gap-1">
                                                <button class="btn btn-outline-primary btn-sm btn-counter"
                                                    data-quantity="-" type="button">-</button>
                                                <input type="number" class="form-control form-control-sm"
                                                    name="form_quantity" value=1>
                                                <button class=" btn btn-outline-primary btn-sm btn-counter"
                                                    data-quantity="+" type="button">+</button>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <span id="product_stock" class="m-0"></span>
                                        </div>
                                    </div>
                                    <span class="text-muted">Total Price: </span>
                                    <h4 class="m-0 text-primary" id="product_total"></h4>
                                </div>
                            </div>
                        </div>

                        <div class=" row m-0 g-2">
                            <div class="col-12 col-lg-6">
                                <button type="submit" class="btn btn-success w-100">Order</button>
                            </div>

                            <div class="col-12 col-lg-6">
                                <button type="button" class="btn btn-secondary w-100" data-bs-dismiss="modal"
                                    aria-label="Cancel">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
<script>
    let maxStock;
    let itemPrice;

    const viewProduct = data => {
        $('#viewProduct input[name="form_quantity"').val("1");
        $.ajax({
            type: "GET",
            url: `pages/requests/GET_data_info.php?tbl=products_user&data=${data}`,
            dataType: 'json',
            success: function (response) {
                const data = response.data;
                maxStock = data.total_stock
                itemPrice = data.selling_price_int;
                $('#viewProduct #product_name').text(data.product_name)
                $('#viewProduct input[name="form_data_id"]').val(data.product_id)
                $('#viewProduct #product_img').attr('src', data.image)
                $('#viewProduct #product_category').text(data.category)
                $('#viewProduct #product_category').text(data.category)
                $('#viewProduct #product_price').text(data.selling_price)
                $('#viewProduct #product_total').text(`₱ ${data.selling_price_int}.00`)
                $('#viewProduct #product_supplier').text(`- ${data.supplier} -`)
                $('#viewProduct #product_stock').text(`${data.total_stock} ${data.unit} available`)
            }
        });
    }
    $(document).ready(function () {
        let categorySelected = false;

        // Event handler for buttons with data-sort attribute
        $('[data-sort]').on('click', function (event) {
            const selectedSort = $(this).data('sort');
            const currentURL = new URL(window.location.href);

            if (selectedSort === 'category' && !categorySelected) {
                // Prevent default behavior if no category is selected
                event.preventDefault();
            } else {
                // Update the URL with the selected sorting option
                const selectedValue = (selectedSort === 'category') ? $('#form-sort-category').val() : selectedSort;
                currentURL.searchParams.set(selectedSort === 'category' ? 'category' : 'sort', selectedValue);
                window.location.href = currentURL.toString();
            }
        });

        $.ajax({
            method: "GET",
            url: "pages/requests/GET_data.php?data=categories",
            dataType: "json",
            success: function (response) {
                response.data.sort(function (a, b) {
                    var nameA = a.category_name.toLowerCase();
                    var nameB = b.category_name.toLowerCase();
                    if (nameA < nameB) {
                        return -1;
                    }
                    if (nameA > nameB) {
                        return 1;
                    }
                    return 0;
                });
                category_list = response.data;
                $.each(response.data, function (indexInArray, valueOfElement) {
                    if (valueOfElement.status === 'Active') {
                        $('#form-sort-category').append($('<option>', {
                            value: valueOfElement.category_id,
                            text: `${valueOfElement.category_name}`
                        }));

                    }
                });
                $('#form-sort-category').val(<?php echo $category ?>)
                $('#loader_container').fadeOut();
            }
        });

        $('#form-sort-category').on('change', function () {
            const selectedCategory = $(this).val();
            categorySelected = !!selectedCategory;
        });

        $('#viewProduct input[name="form_quantity"]').on('input', function (event) {
            var value = $(this).val();

            // Check for single leading 0
            if (/^0$/.test(value)) {
                value = ''; // Set to empty string if it's just a single 0
            } else {
                // Allow other digits
                value = value.replace(/[^\d]/g, '');
            }

            if (parseInt(value) > parseInt(maxStock)) {
                value = maxStock
            }
            else {
                value = value;
            }
            $(this).val(value);
            $('#viewProduct #product_total').text(`₱ ${parseInt(itemPrice) * value}.00`)
        });

        $('#viewProduct .btn-counter').each(function (index, element) {
            $(this).click(function (e) {
                e.preventDefault();
                if ($(this).data('quantity') === "+") {
                    // Increase the value by one
                    var newValue = parseInt($('#viewProduct input[name="form_quantity"').val()) + 1;
                    // Ensure newValue doesn't exceed the maximum stock
                    newValue = Math.min(newValue, maxStock);
                } else {
                    // Decrease the value by one
                    var newValue = parseInt($('#viewProduct input[name="form_quantity"').val()) - 1;
                    // Ensure newValue doesn't go below 1
                    newValue = Math.max(newValue, 1);
                }
                quantity = newValue;
                $('#viewProduct input[name="form_quantity"').val(newValue);
                $('#viewProduct #product_total').text(`₱ ${parseInt(itemPrice) * newValue}.00`)
            });
        });
    });
</script>