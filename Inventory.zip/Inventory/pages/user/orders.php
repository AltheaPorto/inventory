<!--
    orders.php
    This file displays the orders page for users in the StockSense Inventory Management System.
    It shows the current orders placed by the user.

    Features:
    1. Displays a breadcrumb navigation to indicate the current page location.
    2. Shows a list of orders in a table format with details such as ID, product image, name, price, quantity, total price, category, supplier, and order date.
    3. Includes a modal for previewing product images.
    4. Utilizes DataTables for an interactive and responsive table.
    5. Contains a script to handle image previews and includes additional functionality from `tbl_user_orders.js`.

-->



<div class="container mt-5 mt-lg-0">
    <h2 class="fw-bold">Orders</h2>

    <div class="d-flex align-items-center justify-content-between mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?p=dashboard">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Orders</li>
            </ol>
        </nav>
    </div>


    <div class="card borders-0 p-3">
        <h6 class="fw-bold">
            <i class="fa-solid fa-cart-shopping me-3"></i>
            Orders
        </h6>
        <div class="table-responsive">
            <table id="inventory_tbl" class="stripe cell-border display compact">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Image</th>
                        <th>Product Name</th>
                        <th>Selling Price</th>
                        <th>Quantity</th>
                        <th>Total Price</th>
                        <th>Category</th>
                        <th>Supplier</th>
                        <th>Date Ordered</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>


    <div class="modal fade" id="modal_image_preview" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false"
        role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <p class="m-0">Product preview</p>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>


</div>
<script>

    const preview = image => {
        $('#modal_image_preview .modal-body').empty();
        $('#modal_image_preview .modal-body').append(`<img src=${image.src} class="img-fluid"/>`);
    }


</script>
<script src="pages/requests/javascript/tbl_user_orders.js"></script>