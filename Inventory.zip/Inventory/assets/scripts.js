$(window).on('load', function () {
	const sidebar_trigger = () => {
		var $trigger = $('#trigger_sidebar #trigger');
		var currentState = $trigger.data('state');
		var newState = currentState === 'open' ? 'close' : 'open';

		$trigger.data('state', newState);
		$('#trigger_sidebar').attr(
			'title',
			newState === 'open' ? 'Close Sidebar' : 'Open Sidebar'
		);

		$('body').attr('data-sidebar', newState);

		console.log(newState);
	};

	$('#trigger_sidebar').click(sidebar_trigger);
	$('.trigger_mobile').click(sidebar_trigger);
});
