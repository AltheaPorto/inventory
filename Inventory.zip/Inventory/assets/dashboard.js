$(document).ready(function () {
	const INTEGRA_1000_CANVAS = $('#1k_canvas')[0];
	const INTEGRA_2000_CANVAS = $('#2k_canvas')[0];
	const INTEGRA_3000_CANVAS = $('#3k_canvas')[0];
	const SALES = $('#sales_dropdown');
	const TOP = $('#selling_dropdown');

	Chart.register({
		id: 'center-value',
		afterDraw: function (chart) {
			const ctx = chart.ctx;
			const centerX = chart.chartArea.left + chart.chartArea.width / 2;
			const centerY = chart.chartArea.top + chart.chartArea.height / 2;
			const currentValue = chart.data.datasets[0].data[0];
			const maxValue =
				parseInt(chart.data.datasets[0].data[1]) + parseInt(currentValue);

			ctx.save();
			ctx.font = '1.5em Poppins';
			ctx.textAlign = 'center';
			ctx.fillStyle = '#000';
			ctx.fillText(
				`${parseInt(maxValue !== 0 ? (currentValue / maxValue) * 100 : 0)}%`,
				centerX,
				centerY + Math.floor(centerY / 3)
			);
			ctx.font = '1em Poppins';
			ctx.textAlign = 'center';
			ctx.fillText(
				`${currentValue}kg / ${maxValue}kg `,
				centerX,
				centerY + Math.floor(centerY / 1.5)
			);
			ctx.restore();
		},
	});

	function setupDoughnutChart(canvas, maxValue, currentValue) {
		return new Chart(canvas, {
			type: 'doughnut',
			data: {
				datasets: [
					{
						data: [currentValue, maxValue - currentValue],
						backgroundColor: ['#dc3545', 'rgba(0, 0, 0, 0.1)'],
					},
				],
			},
			options: {
				rotation: 270,
				circumference: 180,
				plugins: {
					legend: {
						display: false,
					},
					tooltip: {
						enabled: false,
					},
					centerValue: {
						id: 'center-value',
					},
				},
				hover: {
					mode: null,
				},
			},
		});
	}

	function drawCanvas(category, max, current) {
		switch (category) {
			case '1':
				setupDoughnutChart(INTEGRA_1000_CANVAS, max, current);
				break;
			case '2':
				setupDoughnutChart(INTEGRA_2000_CANVAS, max, current);
				break;
			case '3':
				setupDoughnutChart(INTEGRA_3000_CANVAS, max, current);
				break;
		}
	}

	function getTotalQuantityByFeedType(category) {
		$.ajax({
			url: `app/requests/fetch_loaded_feeds.php?id=${category}`,
			dataType: 'json',
			success: function (data) {
				drawCanvas(
					category,
					data[0].total_weight_loaded,
					data[0].current_weight_loaded
				);
			},
			error: function (xhr, status, error) {
				console.error('Error fetching inventory data:', error);
			},
		});
	}

	getTotalQuantityByFeedType('1');
	getTotalQuantityByFeedType('2');
	getTotalQuantityByFeedType('3');

	$(SALES).change(function (e) {
		$.ajax({
			url: `app/requests/fetch_usage.php?usage=${e.target.value}`,
			dataType: 'json',
			success: function (data) {
				$('#sales_count').html(`${data[0]['usage']} kg`);
			},
			error: function (xhr, status, error) {
				console.error('Error fetching inventory data:', error);
			},
		});
	});

	$(TOP).change(function (e) {
		$.ajax({
			url: `app/requests/fetch_sales.php?usage=${e.target.value}`,
			dataType: 'json',
			success: function (data) {
				let value = data[0].max_value;
				let brand_name = data[0].category_name;
				let path = brand_name.replace(/ /g, '_');

				if (value != 0) {
					$('#brand_name').html(brand_name);
					$('#top_selling_brand_count').html(`${value} kg`);

					$('#brand_image').attr('src', `images/${path}.png`);
				} else {
					$('#brand_name').html('');
					$('#top_selling_brand_count').html('');
					$('#brand_image').attr('src', '');
				}
			},
			error: function (xhr, status, error) {
				console.error('Error fetching inventory data:', error);
			},
		});
	});

	$(SALES).trigger('change');
	$(TOP).trigger('change');
});
