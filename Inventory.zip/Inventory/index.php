<?php
/**
 * index.php
 *
 * This file serves as the entry point for the application. It performs the following tasks:
 *
 * 1. Starts a new session or resumes an existing session.
 * 2. Includes the necessary configuration, database connection, and table definition files.
 * 3. Checks if the user is logged in by verifying the presence of a session variable 'user_id'.
 * - If the user is logged in, it includes the main index page.
 * - If the user is not logged in, it includes the login page.
 *
 */


session_start();
require_once ('required/config.php');
require_once ('required/db_conn.php');
require_once ('required/table.php');

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    // Include the index page if the user is already logged in
    include_once 'pages/index.php';
    exit();
}

// Include the login page if the user is not logged in
require_once 'pages/login.php';
