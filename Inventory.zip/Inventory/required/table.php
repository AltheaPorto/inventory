<?php
/**
 * table.php
 * 
 * This file handles the creation of various tables required by the application. It performs the following tasks:
 * 
 * 1. Defines and creates the `users_tbl` table if it does not already exist.
 *    - Includes fields for user details such as `user_id`, `first_name`, `last_name`, `username`, `password`, `role`, `status`, `last_login`, and `created_at`.
 *    - Checks for an existing admin account and creates one if it doesn't exist, hashing the password for security.
 * 
 * 2. Defines and creates the `supplier_tbl` table if it does not already exist.
 *    - Includes fields for supplier details such as `supplier_id`, `supplier_name`, `coordinator_name`, `province_id`, `municipality_id`, `barangay_id`, `address`, `phone`, and `created_at`.
 * 
 * 3. Defines and creates the `categories_tbl` table if it does not already exist.
 *    - Includes fields for category details such as `category_id`, `category_name`, `status`, and `created_at`.
 * 
 * 4. Defines and creates the `products_tbl` table if it does not already exist.
 *    - Includes fields for product details such as `product_id`, `product_name`, `buying_price`, `selling_price`, `quantity`, `unit`, `category_id`, `supplier_id`, `image`, `stock_value`, `initial_stock`, and `created_at`.
 *    - Establishes foreign key relationships with `categories_tbl` and `supplier_tbl`.
 * 
 * 5. Defines and creates the `orders_tbl` table if it does not already exist.
 *    - Includes fields for order details such as `order_id`, `user_id`, `product_id`, `quantity`, and `created_at`.
 *    - Establishes foreign key relationships with `users_tbl` and `products_tbl`.
 * 
 * 6. Defines and creates the `restock_tbl` table if it does not already exist.
 *    - Includes fields for restock details such as `restock_id`, `product_id`, `quantity`, `unit`, and `restock_date`.
 *    - Establishes a foreign key relationship with `products_tbl`.
 */


$users_tbl = "CREATE TABLE IF NOT EXISTS `users_tbl` (
    `user_id` INT NOT NULL AUTO_INCREMENT ,
    `first_name` VARCHAR(255) NOT NULL ,
    `last_name` VARCHAR(255) NOT NULL ,
    `username` VARCHAR(255) NOT NULL ,
    `password` TEXT NOT NULL ,
    `role` TINYINT NOT NULL DEFAULT '1' ,
    `status` VARCHAR(50) NOT NULL DEFAULT 'Active',
    `last_login` TIMESTAMP NULL DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`)
) ENGINE = InnoDB;";

if ($conn->query($users_tbl) !== TRUE) {
    echo "Error creating USERS table: " . $conn->error;
}

$adminUsername = 'admin';
$adminFirstName = 'Admin';
$adminLastName = 'Istrator';
$adminPassword = '@dmin1234';
$adminRole = 0;

$checkQuery = "SELECT COUNT(*) AS admin_count FROM users_tbl WHERE username = ?";
$stmt = $conn->prepare($checkQuery);
$stmt->bind_param("s", $adminUsername);
$stmt->execute();
$result = $stmt->get_result();
$adminCount = $result->fetch_assoc()['admin_count'];

if ($adminCount == 0) {
    $hashedPassword = password_hash($adminPassword, PASSWORD_DEFAULT);

    $insertQuery = "INSERT INTO users_tbl (first_name, last_name, username, password, role) VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($insertQuery);

    $stmt->bind_param("ssssi", $adminFirstName, $adminLastName, $adminUsername, $hashedPassword, $adminRole);
    $stmt->execute();

    if ($stmt->affected_rows < 0) {
        echo "Error creating admin account: " . $stmt->error;
    }

    $stmt->close();
}

$supplier_tbl = "CREATE TABLE IF NOT EXISTS `supplier_tbl` (
    `supplier_id` INT NOT NULL AUTO_INCREMENT,
    `supplier_name` VARCHAR(255) NOT NULL,
    `coordinator_name` VARCHAR(255),
    `province_id` VARCHAR(10),
    `municipality_id` VARCHAR(10),
    `barangay_id` TEXT,
    `address` TEXT,
    `phone` INT(11) NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`supplier_id`)
) ENGINE = InnoDB;";

// Execute query
if ($conn->query($supplier_tbl) !== TRUE) {
    echo "Error creating SUPPLIERS table: " . $conn->error;
}

$categories_tbl = "CREATE TABLE IF NOT EXISTS `categories_tbl` (
                `category_id` INT NOT NULL AUTO_INCREMENT,
                `category_name` VARCHAR(255) NOT NULL,
                `status` VARCHAR(50) NOT NULL DEFAULT 'Active',
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`category_id`)
            ) ENGINE = InnoDB;
            ";

// Execute query
if ($conn->query($categories_tbl) !== TRUE) {
    echo "Error creating CATEGORIES table: " . $conn->error;
}

$products_sql = "CREATE TABLE IF NOT EXISTS `products_tbl` (
    `product_id` INT NOT NULL AUTO_INCREMENT,
    `product_name` VARCHAR(255) NOT NULL,
    `buying_price` INT NOT NULL,
    `selling_price` INT NOT NULL,
    `quantity` INT NOT NULL,
    `unit` VARCHAR(50) NOT NULL DEFAULT '-',
    `category_id` INT NOT NULL,
    `supplier_id` INT NOT NULL,
    `image` LONGTEXT NOT NULL,
    `stock_value` INT NOT NULL DEFAULT 0,
    `initial_stock` INT NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`product_id`),
    FOREIGN KEY (`category_id`) REFERENCES `categories_tbl` (`category_id`),
    FOREIGN KEY (`supplier_id`) REFERENCES `supplier_tbl` (`supplier_id`)
) ENGINE = InnoDB;";

// Execute query
if ($conn->query($products_sql) !== TRUE) {
    echo "Error creating PRODUCTS table: " . $conn->error;
}

$orders_tbl = "CREATE TABLE IF NOT EXISTS `orders_tbl` (
    `order_id` INT NOT NULL AUTO_INCREMENT,
    `user_id` INT NOT NULL,
    `product_id` INT NOT NULL,
    `quantity` INT NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`order_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users_tbl`(`user_id`),
    FOREIGN KEY (`product_id`) REFERENCES `products_tbl`(`product_id`)
) ENGINE = InnoDB;";

// Execute query
if ($conn->query($orders_tbl) !== TRUE) {
    echo "Error creating ORDERS table: " . $conn->error;
}

// SQL statement to create restock_tbl table
$restock_tbl = "CREATE TABLE IF NOT EXISTS `restock_tbl` (
    `restock_id` INT NOT NULL AUTO_INCREMENT,
    `product_id` INT NOT NULL,
    `quantity` INT NOT NULL,
    `unit` VARCHAR(50) NOT NULL,
    `restock_date` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`restock_id`),
    FOREIGN KEY (`product_id`) REFERENCES `products_tbl`(`product_id`)
) ENGINE = InnoDB;";

// Execute query
if ($conn->query($restock_tbl) !== TRUE) {
    echo "Error creating RESTOCK table: " . $conn->error;
}
