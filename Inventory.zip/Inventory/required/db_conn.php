<?php

/**
 * db_conn.php
 * 
 * This file handles the connection to the database. It performs the following tasks:
 * 
 * 1. Includes the configuration file to access database-related constants.
 * 2. Creates a connection to the MySQL database using the provided host, user, and password constants.
 * 3. Checks if the connection is successful and terminates the script if it fails.
 * 4. Creates the specified database if it does not already exist.
 * 5. Selects the newly created or existing database for use.
 * 
 */

require_once ("config.php");

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);


// Check connection
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}


// Create database if not existing
$sql = "CREATE DATABASE IF NOT EXISTS " . DB_NAME;
if (!$conn->query($sql) === TRUE) {
    die("Error creating database: " . $conn->error);
}

// Select the newly created database
$conn->select_db(DB_NAME);