<?php

/**
 * config.php
 * 
 * This file defines a collection of constant variables used throughout the application. These constants include:
 * 
 * 1. Application-related constants:
 *    - APP_NAME: The name of the application.
 *    - APP_LOGO: The path to the application's logo image.
 *    - FAVICON_16: The path to the 16x16 favicon image.
 *    - FAVICON_32: The path to the 32x32 favicon image.
 * 
 * 2. Database-related constants:
 *    - DB_HOST: The hostname of the database server.
 *    - DB_USER: The username for accessing the database.
 *    - DB_PASS: The password for accessing the database.
 *    - DB_NAME: The name of the database to be used.
 * 
 */

define("APP_NAME", "AppliHub");
define("APP_LOGO", "assets/images/logo.jpg");
define("FAVICON_16", "assets/images/favicon-16x16.png");
define("FAVICON_32", "assets/images/favicon-32x32.png");

# Database-related
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "inventory_db");
